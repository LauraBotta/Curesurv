library(testthat)
library(curesurv)

test_check("curesurv")
