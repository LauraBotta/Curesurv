AIC.cursurv <- function(object, ..., k = 2){
  if (class(object)[1] == "curesurv") {
    return(2*object$loglik + 2 * length(object$estimates))
  }else{
    stop("not implemented for this type of object")
  }
  invisible()
}
