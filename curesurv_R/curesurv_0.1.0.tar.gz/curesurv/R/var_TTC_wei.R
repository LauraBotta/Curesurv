#' @title var_TTC_wei function
#'
#' @description Calculates the variance of TTC with delta method. The expression
#' of this variance is expressed as Var(TTC) = (dTTC/dtheta)Var(theta)(dTTC/dtheta)^T
#' where Var(theta) is the variance-covariance matrix of theta.
#'
#'
#' @param object ouput from a model implemented in curesurv
#'
#' @param z_ucured covariates matrix acting on survival function of uncured
#'
#' @param z_pcured covariates matrix acting on cure proportion
#'
#' @param epsilon  value fixed by user to estimate the TTC Pi(t)≥ (1-epsilon).
#'   By default epsilon = 0.05.

var_TTC_wei <- function(object,
                        z_ucured =  z_ucured,
                        z_pcured = z_pcured,
                        epsilon = epsilon)
{
  dTTC_dtheta <-  dTTCdtheta_wei(z_ucured =  z_ucured,
                                 z_pcured = z_pcured,
                                 theta = object$coefficients,
                                 epsilon = epsilon)

  if(object$pophaz.alpha) {
    varTTC <- dTTC_dtheta %*%
      object$varcov_star[1:(ncol(object$varcov_star)-1),1:(ncol(object$varcov_star)-1)] %*%
      t(dTTC_dtheta)
  }else{
    varTTC <- dTTC_dtheta %*%
      object$varcov_star %*%
      t(dTTC_dtheta)
  }


  return(varTTC)
}
