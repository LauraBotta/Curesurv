#' @title sn_ic_adtneh2 function
#'
#' @description calculates the net survival at time t. It also provides
#'  the related confidence intervals using plain_method.
#'
#' @param object ouput from a model implemented in curesurv
#'
#' @param z_alpha Covariates matrix acting on parameter alpha of the density of
#'  time-to-null excess hazard model
#'
#' @param z_tau Covariates matrix acting on time-to-null parameter.
#'
#' @param x time at which the predictions are provided
#'
#' @param level (1-alpha/2)-order quantile of a normal distribution
#'
#' @author Juste Goungounga, Eugenie Blandin, Olayidé Boussari, Valérie Jooste
#'
#' @references Boussari O, Bordes L, Romain G, Colonna M, Bossard N, Remontet L,
#'  Jooste V. Modeling excess hazard with time-to-cure as a parameter.
#'   Biometrics. 2021 Dec;77(4):1289-1302. doi: 10.1111/biom.13361.
#'    Epub 2020 Sep 12. PMID: 32869288.
#' (\href{https://pubmed.ncbi.nlm.nih.gov/32869288/}{pubmed})


sn_ic_adtneh2 <-  function(z_tau = z_tau,
                          z_alpha = z_alpha,
                          x = x,
                          object = object,
                          level = level){

  sn <- cumLexc_ad2_topred(z_tau,
                                z_alpha,
                                x,
                                theta = object$coefficients)$netsurv
  varsn <- diag(varsn_adtneh2(z_tau, z_alpha, x, object))



  borne_inf <-  sn - stats::qnorm(level) * sqrt(varsn)
  borne_sup <-  sn + stats::qnorm(level) * sqrt(varsn)

  IC <- list(sn = sn,
             borne_inf = borne_inf,
             borne_sup = borne_sup)

  return(IC)

}
