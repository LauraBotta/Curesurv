#' @title varsn_adtneh2 function

#' @description calculates the variance of net survival at time t.
#'
#' @param object ouput from a model implemented in curesurv
#'
#' @param z_alpha Covariates matrix acting on parameter alpha of the density of
#'  time-to-null excess hazard model
#'
#' @param z_tau Covariates matrix acting on time-to-null parameter.
#'
#' @param x time at which the predictions are provided
#'
#' @author Juste Goungounga, Olayidé Boussari, Eugenie Blandin, Valérie Jooste
#'
#' @references Boussari O, Bordes L, Romain G, Colonna M, Bossard N, Remontet L,
#'  Jooste V. Modeling excess hazard with time-to-cure as a parameter.
#'  Biometrics. 2021 Dec;77(4):1289-1302. doi: 10.1111/biom.13361.
#'  Epub 2020 Sep 12. PMID: 32869288.
#' (\href{https://pubmed.ncbi.nlm.nih.gov/32869288/}{pubmed})

varsn_adtneh2 <- function(z_tau, z_alpha, x, object) {

  Dsn <- dsndtheta_adtneh2(z_tau, z_alpha, x, object)
  varsn <- Dsn %*% object$varcov_star %*% t(Dsn)
  return(varsn)
}
