#' @title predcall_wei function
#'
#' @description calculates the predicted cure indicators from a mixture cure
#'  model with the survival of uncured specified by a Weibull distribution.
#'
#'
#' @param object ouput from a model implemented using curesurv
#'
#' @param pred some predicted estimates
#'
#' @param z_ucured covariates matrix acting on survival function of uncured
#'
#' @param z_pcured covariates matrix acting on cure proportion
#'
#' @param x time at which the predictions are provided
#'
#' @param level (1-alpha/2)-order quantile of a normal distribution
#'
#' @param epsilon  value fixed by user to estimate the TTC Pi(t)≥ (1-epsilon).
#'   By default epsilon = 0.05.
#'
#' @param  sign_delta only used for mixture cure rate models to specify if the
#' effects or minus the effects of covariates acting on uncured survival to be
#' considered. Default will be sign_delta = "1". The alternative is
#' sign_delta = "-1".
#'
#'
#' @author Juste Goungounga, Olayidé Boussari, Valérie Jooste
#'
#' @references Boussari O, Bordes L, Romain G, Colonna M, Bossard N, Remontet L,
#'  Jooste V. Modeling excess hazard with time-to-cure as a parameter.
#'   Biometrics. 2021 Dec;77(4):1289-1302. doi: 10.1111/biom.13361.
#'    Epub 2020 Sep 12. PMID: 32869288.
#' (\href{https://pubmed.ncbi.nlm.nih.gov/32869288/}{pubmed})
#'
#'
#'  Boussari O, Romain G, Remontet L, Bossard N, Mounier M, Bouvier AM,
#'  Binquet C, Colonna M, Jooste V. A new approach to estimate time-to-cure from
#'  cancer registries data. Cancer Epidemiol. 2018 Apr;53:72-80.
#'  doi: 10.1016/j.canep.2018.01.013. Epub 2018 Feb 4. PMID: 29414635.
#' (\href{https://pubmed.ncbi.nlm.nih.gov/29414635/}{pubmed})
#'
#'
#'  Phillips N, Coldman A, McBride ML. Estimating cancer prevalence using
#'  mixture models for cancer survival. Stat Med. 2002 May 15;21(9):1257-70.
#'  doi: 10.1002/sim.1101. PMID: 12111877.
#'  (\href{https://pubmed.ncbi.nlm.nih.gov/12111877/}{pubmed})
#'
#'
#'   De Angelis R, Capocaccia R, Hakulinen T, Soderman B, Verdecchia A. Mixture
#'   models for cancer survival analysis: application to population-based data
#'   with covariates. Stat Med. 1999 Feb 28;18(4):441-54.
#'   doi: 10.1002/(sici)1097-0258(19990228)18:4<441::aid-sim23>3.0.co;2-m.
#'   PMID: 10070685.
#'   (\href{https://pubmed.ncbi.nlm.nih.gov/10070685/}{pubmed})

predcall_wei <- function(object,
                         pred,
                         z_pcured = z_pcured,
                         z_ucured = z_ucured,
                         x = x,
                         level = level,
                         epsilon = epsilon, sign_delta = 1) {

  theta <- object$coefficients

  pred$time_to_cure_ttc <- TTC_wei(z_pcured = z_pcured,
                                   z_ucured = z_ucured,
                                   theta = object$coefficients,
                                   epsilon = epsilon)
  pred$p_ttc <- pt_cure_wei(z_pcured = z_pcured, z_ucured = z_ucured,
                            x = pred$time_to_cure_ttc, theta = object$coefficients)


  pred$netsurv_ttc <- exp(-cumLexc_alphaweibull_topred(z_ucured =  z_ucured,
                                                       z_pcured = z_pcured,
                                                       x = pred$time_to_cure_ttc,
                                                       theta,  sign_delta = sign_delta)$cumhaz)

  # Confidence interval of p(t) by Delta Method on P(t)

  pt_ic <- pt_cure_ic_wei(object,
                          z_pcured = z_pcured,
                          z_ucured = z_ucured,
                          x = x,
                          level = level)


  pred$borne_inf_pt_ic <- pt_ic$borne_inf
  pred$borne_sup_pt_ic <- pt_ic$borne_sup

  # Confidence interval of p(TTC) by Delta Method on P(t)
  pttc_ic <- pt_cure_ic_wei(object, z_pcured = z_pcured,
                            z_ucured = z_ucured,
                            x = pred$time_to_cure,
                            level)
  pred$borne_inf_pttc_ic <- pttc_ic$borne_inf
  pred$borne_sup_pttc_ic <- pttc_ic$borne_sup

  # Confidence interval of p(t) by log(p(t)) by delta method on log(p(t))
  pt_ic_log <- pt_cure_ic_log_wei(object, z_pcured = z_pcured,
                                  z_ucured = z_ucured,
                                  x= x,
                                  level)

  pred$borne_inf_pt_ic_log <- pt_ic_log$borne_inf
  pred$borne_sup_pt_ic_log <- pt_ic_log$borne_sup

  # Confidence interval of p(TTC) by delta method on log(p(t))
  pttc_ic_log <- pt_cure_ic_log_wei(object, z_pcured = z_pcured,
                                    z_ucured = z_ucured,
                                    x = pred$time_to_cure,
                                    level)
  pred$borne_inf_pttc_ic_log <- pttc_ic_log$borne_inf
  pred$borne_sup_pttc_ic_log <- pttc_ic_log$borne_sup

  # Confidence interval of p(t) by delta method on log(-log(p(t)))
  pt_ic_loglog <- pt_cure_ic_loglog_wei(object, z_pcured = z_pcured,
                                        z_ucured = z_ucured,
                                        x = x,
                                        level)
  pred$borne_inf_pt_ic_loglog <- pt_ic_loglog$borne_inf
  pred$borne_sup_pt_ic_loglog <- pt_ic_loglog$borne_sup


  # Confidence interval of p(TTC) by delta method on log(-log(p(t)))
  pttc_ic_loglog <- pt_cure_ic_loglog_wei(object, z_pcured = z_pcured,
                                          z_ucured = z_ucured,
                                          x = pred$time_to_cure,
                                          level)
  pred$borne_inf_pttc_ic_loglog <- pttc_ic_loglog$borne_inf
  pred$borne_sup_pttc_ic_loglog  <- pttc_ic_loglog$borne_sup


  # Confidence interval of Sn(t) by  delta method on Sn(t)
  sn_ic <- sn_ic_wei(object,
                     z_pcured = z_pcured,
                     z_ucured = z_ucured,
                     x = x,
                     level)

  pred$borne_inf_sn_ic <- sn_ic$borne_inf
  pred$borne_sup_sn_ic <- sn_ic$borne_sup

  # Confidence interval of Sn(TTC) by  delta method on Sn(t)
  snttc_ic <- sn_ic_wei(object,
                        z_pcured = z_pcured,
                        z_ucured = z_ucured,
                        x = pred$time_to_cure,
                        level)

  pred$borne_inf_snttc_ic <- snttc_ic$borne_inf
  pred$borne_sup_snttc_ic <- snttc_ic$borne_sup

  # Confidence interval of Sn(t) by  delta method on log(Sn(t))
  sn_ic_log <- sn_ic_log_wei(object,
                         z_pcured = z_pcured,
                         z_ucured = z_ucured,
                         x = x,
                         level)

  pred$borne_inf_sn_ic_log <- sn_ic_log$borne_inf
  pred$borne_sup_sn_ic_log <- sn_ic_log$borne_sup

  # Confidence interval of Sn(TTC) by  delta method on log(Sn(t))
  snttc_ic_log <- sn_ic_log_wei(object,
                                z_pcured = z_pcured,
                                z_ucured = z_ucured,
                                x = pred$time_to_cure,
                                level)

  pred$borne_inf_snttc_ic_log <- snttc_ic_log$borne_inf
  pred$borne_sup_snttc_ic_log <- snttc_ic_log$borne_sup

  # Confidence interval of Sn(t) by  delta method on log(-log(Sn(t)))
  logCumHaz_ic <- logCumHaz_ic_wei(object,
                               z_pcured = z_pcured,
                               z_ucured = z_ucured,
                               x = x,
                               level)

  pred$borne_inf_logCumHaz_ic <- logCumHaz_ic$borne_inf
  pred$borne_sup_logCumHaz_ic <- logCumHaz_ic$borne_sup
  pred$borne_inf_sn_ic_loglog <- exp(-exp(logCumHaz_ic$borne_sup))
  pred$borne_sup_sn_ic_loglog <- exp(-exp(logCumHaz_ic$borne_inf))

  logCumHazttc_ic <- logCumHaz_ic_wei(object,
                                  z_pcured = z_pcured,
                                  z_ucured = z_ucured,
                                  x = pred$time_to_cure,
                                  level)

  pred$borne_inf_snttc_ic_loglog <- exp(-exp(logCumHazttc_ic$borne_sup))
  pred$borne_sup_snttc_ic_loglog <- exp(-exp(logCumHazttc_ic$borne_inf))

  TTC_ic <- TTC_ic_wei(object, z_pcured = z_pcured,
                       z_ucured = z_ucured,
                       epsilon = epsilon, level)

  pred$time_to_cure_ttc <- TTC_ic$time_to_cure_ttc
  pred$borne_inf_TTC_ic <- TTC_ic$borne_inf
  pred$borne_sup_TTC_ic <- TTC_ic$borne_sup


pred$varlogTTC <- varlogTTC_wei(object,
                                z_ucured =  z_ucured,
                                z_pcured = z_pcured,
                                epsilon = epsilon)


  TTC_ic_log <- TTC_ic_log_wei(varlogTTC = pred$varlogTTC,
                               time_to_cure_ttc = pred$time_to_cure_ttc,
                               epsilon = 0.05, level)
  pred$borne_inf_TTC_ic_log <- TTC_ic_log$borne_inf
  pred$borne_sup_TTC_ic_log  <- TTC_ic_log$borne_sup


  pred$var_TTC_Jakobsen <- var_TTC_Jakobsen_wei(object,
                                                z_ucured =  z_ucured,
                                                z_pcured = z_pcured,
                                                epsilon = epsilon)
  pred$var_TTC <- var_TTC_wei(object,
                         z_ucured =  z_ucured,
                         z_pcured = z_pcured,
                         epsilon = epsilon)

  pred$varlogTTC_Jakobsen <- varlogTTC_Jakobsen_wei(object,
                                               z_ucured =  z_ucured,
                                               z_pcured = z_pcured,
                                               epsilon = epsilon)

  pred$model <- object$model
  pred$dist <- object$dist
  pred$epsilon <- epsilon

  return(pred)
}
