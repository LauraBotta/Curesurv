#' @title pi_ic_adtneh2_loglog function
#'
#' @description produces confidence interval of cure fraction pi using a
#'  time-to-null excess hazard model with linear effect on parameter tau
#'  The confidence intervals based on log-log method.
#'
#'
#' @param z_tau Covariates matrix acting on time-to-null parameter.
#'
#'
#' @param z_alpha Covariates matrix acting on parameter alpha of the density of
#'  time-to-null excess hazard model
#'
#'
#' @param x time at which the predictions are provided
#'
#'
#' @param object ouput from a model implemented in curesurv
#'
#'
#' @param level \code{(1-alpha/2)}-order quantile of a normal distribution


pi_ic_adtneh2_loglog <-  function(z_tau = z_tau,
                                  z_alpha = z_alpha,
                                  x = x,
                                  object,
                                  level = level) {


  Dpi <- dpidtheta_adtneh2(z_tau = z_tau,
                           z_alpha = z_alpha,
                           x = x,
                           object)

  cumLexctopred <- cumLexc_ad2_topred(z_tau = z_tau,
                                      z_alpha = z_alpha,
                                      x = x,
                                      theta = object$coefficients)

  cumLexc <- cumLexctopred$cumhaz
  pi <- cumLexctopred$pi


  Dloglog <- sweep(Dpi, 1/(pi*log(pi)), MARGIN = 1, '*' )

  varloglogpi <- diag(Dloglog %*% object$varcov_star %*% t(Dloglog))


  borne_inf <-  exp(-exp(log(-log(pi)) + stats::qnorm(level) * sqrt(varloglogpi)))
  borne_sup <-  exp(-exp(log(-log(pi)) - stats::qnorm(level) * sqrt(varloglogpi)))

  IC <- list(pi = pi,
             borne_inf = borne_inf,
             borne_sup = borne_sup)

  return(IC)

}
