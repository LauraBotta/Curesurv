#' @title varloglogp_wei function
#'
#' @description Variance of \code{log(log(p(t)))} with delta method.
#' \code{Var(log(log(p(t)))) = (dloglog(p(t)/dtheta)Var(theta)(dloglog(p(t)/dtheta)^T}
#' where Var(theta) is the variance-covariance matrix of theta
#'
#' @param object ouput from model implemented in curesurv
#'
#' @param z_ucured covariates matrix acting on survival function of uncured
#'
#' @param z_pcured covariates matrix acting on cure proportion
#'
#' @param x time at which the estimates are predicted

varloglogp_wei <- function(object, z_pcured = z_pcured,
                           z_ucured = z_ucured, x) {
  dloglogpdtheta <- dloglogpdtheta_wei(
    z_pcured = z_pcured,
    z_ucured = z_ucured,
    x = x,
    theta = object$coefficients
  )

if (object$pophaz.alpha) {
  var_loglogpt <- (t(unlist(dloglogpdtheta))) %*%
    object$varcov_star[1:(ncol(object$varcov_star)-1),1:(ncol(object$varcov_star)-1)] %*%
    t(t(unlist(dloglogpdtheta)))
}else {
  var_loglogpt <- (t(unlist(dloglogpdtheta))) %*%
    object$varcov_star %*%
    t(t(unlist(dloglogpdtheta)))
}


  return(var_loglogpt)
}
