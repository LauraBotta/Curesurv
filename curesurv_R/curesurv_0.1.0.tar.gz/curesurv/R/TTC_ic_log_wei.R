#' @title TTC_ic_log_wei function
#'
#' @description calculates the confidence interval of the time TTC using
#' delta method by assuming normality on log scale of TTC.
#' \code{IC = exp(log(TTC) +/- z*sqrt(var(log(TTC))))},
#' where \code{Var(log(TTC)) = (dlog(TTC)/dtheta)Var(theta)(dlog(TTC)/dtheta)^T}.
#'
#' Note that this function is for mixture cure model with Weibull distribution
#' considered for uncured patients.
#'
#'
#'
#' @param varlogTTC variance of log of TTC.
#'
#' @param time_to_cure_ttc TTC
#'
#'
#' @param epsilon  value fixed by user to estimate the TTC \code{Pi(t)≥ (1-epsilon)}.
#'   By default epsilon = 0.05.
#'
#' @param level \code{1-alpha/2}-order quantile of a normal distribution



TTC_ic_log_wei <- function(varlogTTC = varlogTTC,
                           time_to_cure_ttc = time_to_cure_ttc,
                           epsilon = 0.05, level ) {


  borne_inf <-  exp(log(time_to_cure_ttc) - stats::qnorm(level) * sqrt(varlogTTC))
  borne_sup <-  exp(log(time_to_cure_ttc) + stats::qnorm(level) * sqrt(varlogTTC))

  IC <- list(t = time_to_cure_ttc,
             time_to_cure_ttc = time_to_cure_ttc,
             borne_inf = borne_inf,
             borne_sup = borne_sup)

  return(IC)

}
