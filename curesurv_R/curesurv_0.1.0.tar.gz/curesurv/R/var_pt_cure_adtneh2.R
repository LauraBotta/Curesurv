#' @title var_pt_cure_adtneh2 function
#'
#' @description Variance of p(t) with delta method. Var(p(t)) = (dp/dtheta)Var(theta)(dp/dtheta)^T
#' where Var(theta) is the variance-covariance matrix of theta from a
#' non-mixture cure model with distribution "tneh".
#'
#' @param object ouput from model implemented in curesurv
#'
#' @param z_alpha Covariates matrix acting on parameter alpha of the density of
#'  time-to-null excess hazard model
#'
#' @param z_tau Covariates matrix acting on time-to-null parameter.
#'
#' @param x time at which the estimates are predicted

var_pt_cure_adtneh2 <- function(z_tau = z_tau,
                                z_alpha = z_alpha,
                                x = x,
                                object) {
  if (!inherits(object, "curesurv"))
    stop("Primary argument much be a curesurv object")

  Dp <- dpdtheta_adtneh2(z_alpha = z_alpha,
                         z_tau = z_tau,
                         x = x,
                         object = object)
  varp <- Dp %*% object$varcov_star %*% t(Dp)
  return(varp)
}
