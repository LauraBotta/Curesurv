#'@title pt_cure_ic_loglog_wei function
#'
#' @description confidence intervals of the probability to be cured at time t by
#'  delta method on log(-log(p(t)))
#'
#' @param object ouput from a model implemented in curesurv
#'
#' @param z_ucured covariates matrix acting on survival function of uncured
#'
#' @param z_pcured covariates matrix acting on cure proportion
#'
#' @param x time at which the estimates are predicted
#'
#' @param level (1-alpha/2)-order quantile of a normal distribution


pt_cure_ic_loglog_wei <- function(object,
                             z_pcured = z_pcured,
                             z_ucured = z_ucured,
                             x,
                             level)
{
  varloglogpt <- diag(varloglogp_wei(object,
                                     z_pcured = z_pcured,
                                     z_ucured = z_ucured, x))

  mod_ptcure <- pt_cure_wei(z_pcured = z_pcured,
                            z_ucured = z_ucured, x = x,
                            theta = object$coefficients)

  borne_inf <-
    exp(-exp(log(-log(mod_ptcure)) + stats::qnorm(level) * sqrt(varloglogpt)))
  borne_sup <-
    exp(-exp(log(-log(mod_ptcure)) - stats::qnorm(level) * sqrt(varloglogpt)))
  IC <- list(t = x,
             borne_inf = borne_inf,
             borne_sup = borne_sup)

  return(IC)

}
