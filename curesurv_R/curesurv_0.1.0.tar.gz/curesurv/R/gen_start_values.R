gen_start_values <- function(nvalues,
                             npar,
                             min, max,
                             seed = 1980) {
  set.seed(seed)
  # generate Sobol values
  start <- randtoolbox::sobol(n = nvalues, dim = npar)
  # transform these to lie between min and max on each dimension
  rescale_start <- sapply(1:ncol(start),
                          function(i) {
                            min[i] +
                              (max[i] - min[i]) * start[,i]
                          })
  return(rescale_start)
}


