#' @title var_TTC_Jakobsen_wei function
#'
#' @description Calculates the variance of TTC from a mixture cure model with
#' uncured survival as Weibull distribution using the Jakobsen approach.
#'
#' @param object ouput from a model implemented in curesurv
#'
#' @param z_ucured covariates matrix acting on survival function of uncured
#'
#' @param z_pcured covariates matrix acting on cure proportion
#'
#' @param epsilon  value fixed by user to estimate the TTC \code{Pi(t)≥ (1-epsilon)}.
#'   By default epsilon = 0.05.

var_TTC_Jakobsen_wei <- function(object,
                                 z_ucured =  z_ucured,
                                 z_pcured = z_pcured,
                                 epsilon = epsilon) {
  n_z_pcured <- ncol(z_pcured)
  n_z_pcured <- ncol(z_pcured)
  n_z_ucured <- ncol(z_ucured)
  theta <- object$coefficients
  if (n_z_pcured > 0 & n_z_ucured > 0 ) {
    beta0 <- theta[1]
    betak <- theta[2:(1 + n_z_pcured)]
    lambda <- theta[(1 + n_z_pcured + 1)]
    gamma <- theta[(1 + n_z_pcured + 2)]
    delta <- -theta[(1 + n_z_pcured + 3):(1 + n_z_pcured + 2 + n_z_ucured)]
    pcure <- beta0 + z_pcured %*% betak
    cured <- 1/(1 + exp(-pcure))
    time_to_cure_ttc <- TTC_wei(
      z_pcured = z_pcured,
      z_ucured = z_ucured,
      theta = theta,
      epsilon = epsilon
    )
    x <- time_to_cure_ttc
    usurv <- (exp(-exp(lambda)*(x)^exp(gamma)))^exp(z_ucured %*% delta)
    uhaz <- exp(gamma)*exp(lambda)*((x)^(exp(gamma) - 1)) * exp(z_ucured %*% delta)
    u_f <- uhaz*usurv
    SurvE <- cured + (1 - cured)*usurv
    cumHazE <- -log(SurvE)

    pt_cure <- pt_cure_wei(z_pcured = z_pcured, z_ucured = z_ucured,
                           x = time_to_cure_ttc, theta = theta)
    var_pt <-  var_pt_cure_wei(object,
                               z_pcured = z_pcured,
                               z_ucured = z_ucured, x = time_to_cure_ttc)

    dpdt <- pt_cure^2 * exp(gamma) * exp(lambda) *
      time_to_cure_ttc^(exp(gamma) - 1) *
      usurv * exp(-pcure) * exp(z_ucured %*% delta)
    varTTC <- dpdt^(-2) %*% diag(var_pt)



  } else if (n_z_pcured > 0 & n_z_ucured == 0 ) {
    beta0 <- theta[1]
    betak <- theta[2:(1 + n_z_pcured)]
    lambda <- theta[(1 + n_z_pcured + 1)]
    gamma <- theta[(1 + n_z_pcured + 2)]
    delta <- -theta[(1 + n_z_pcured + 3):(1 + n_z_pcured + 2 + n_z_ucured)]
    pcure <- beta0 + z_pcured %*% betak
    cured <- 1/(1 + exp(-pcure))
    time_to_cure_ttc <- TTC_wei(
      z_pcured = z_pcured,
      z_ucured = z_ucured,
      theta = theta,
      epsilon = epsilon
    )
    x <- time_to_cure_ttc
    usurv <- (exp(-exp(lambda)*(x)^exp(gamma)))
    uhaz <- exp(gamma)*exp(lambda)*((x)^(exp(gamma) - 1))
    u_f <- uhaz*usurv
    SurvE <- cured + (1 - cured)*usurv
    cumHazE <- -log(SurvE)

    pt_cure <- pt_cure_wei(z_pcured = z_pcured, z_ucured = z_ucured,
                           x = time_to_cure_ttc, theta = theta)
    var_pt <-  var_pt_cure_wei(object,
                               z_pcured = z_pcured,
                               z_ucured = z_ucured, x = time_to_cure_ttc)

    dpdt <- pt_cure^2 * exp(gamma) * exp(lambda) *
      time_to_cure_ttc^(exp(gamma) - 1) * usurv * exp(-pcure)
    varTTC <- dpdt^(-2) %*% diag(var_pt)


  } else if (n_z_pcured == 0 & n_z_ucured > 0 ) {
    beta0 <- theta[1]
    lambda <- theta[(1 + n_z_pcured + 1)]
    gamma <- theta[(1 + n_z_pcured + 2)]
    delta <- -theta[(1 + n_z_pcured + 3):(1 + n_z_pcured + 2 + n_z_ucured)]
    pcure <- beta0
    cured <- 1/(1 + exp(-pcure))
    time_to_cure_ttc <- TTC_wei(
      z_pcured = z_pcured,
      z_ucured = z_ucured,
      theta = theta,
      epsilon = epsilon
    )
    x <- time_to_cure_ttc
    usurv <- (exp(-exp(lambda)*(x)^exp(gamma)))^exp(z_ucured %*% delta)
    uhaz <- exp(gamma)*exp(lambda)*((x)^(exp(gamma) - 1)) * exp(z_ucured %*% delta)
    u_f <- uhaz*usurv
    SurvE <- cured + (1 - cured)*usurv
    cumHazE <- -log(SurvE)

    pt_cure <- pt_cure_wei(z_pcured = z_pcured, z_ucured = z_ucured,
                           x = time_to_cure_ttc, theta = theta)
    var_pt <-  var_pt_cure_wei(object,
                               z_pcured = z_pcured,
                               z_ucured = z_ucured, x = time_to_cure_ttc)

    dpdt <- pt_cure ^ 2 * exp(gamma) * exp(lambda) *
      time_to_cure_ttc ^ (exp(gamma) - 1) *
      usurv * exp(-pcure) * exp(z_ucured %*% delta)
    varTTC <- dpdt^(-2) %*% diag(var_pt)









  } else if (n_z_pcured == 0 & n_z_ucured == 0 ) {
    beta0 <- theta[1]
    lambda <- theta[2]
    gamma <- theta[3]
    pcure <- beta0
    cured <- 1/(1 + exp(-pcure))
    time_to_cure_ttc <- TTC_wei(
      z_pcured = z_pcured,
      z_ucured = z_ucured,
      theta = theta,
      epsilon = epsilon
    )
    x <- time_to_cure_ttc
    usurv <- (exp(-exp(lambda)*(x)^exp(gamma)))
    uhaz <- exp(gamma)*exp(lambda)*((x)^(exp(gamma) - 1))
    u_f <- uhaz*usurv
    SurvE <- cured + (1 - cured)*usurv
    cumHazE <- -log(SurvE)


    pt_cure <- pt_cure_wei(z_pcured = z_pcured, z_ucured = z_ucured,
                           x = time_to_cure_ttc, theta = theta)
    var_pt <-  var_pt_cure_wei(object,
                               z_pcured = z_pcured,
                               z_ucured = z_ucured, x = time_to_cure_ttc)

    dpdt <- pt_cure^2 * exp(gamma) * exp(lambda) * time_to_cure_ttc^(exp(gamma) - 1) * usurv * exp(-pcure)
    varTTC <- dpdt^(-2) * diag(var_pt)

    }




  return(varTTC)
}
