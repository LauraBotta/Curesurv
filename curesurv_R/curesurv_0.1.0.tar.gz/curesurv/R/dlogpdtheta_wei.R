#' @title dlogpdtheta_wei function
#'
#' @description Produce partial derivatives of log(p(t)) the logarithm of the
#'  probability to be cured
#'
#' @param z_ucured covariates matrix acting on survival function of uncured
#'
#' @param z_pcured covariates matrix acting on cure proportion
#'
#' @param x time at which the estimates are predicted
#'
#' @param theta estimated parameters of the cumulative excess hazard from a mixture
#'  model using curesurv and uncured survival following a Weibull distribution

dlogpdtheta_wei <- function(z_pcured = z_pcured,
                            z_ucured = z_ucured, x = x,
                            theta) {
    n_z_pcured <- ncol(z_pcured)
    n_z_pcured <- ncol(z_pcured)
    n_z_ucured <- ncol(z_ucured)
    if (n_z_pcured > 0 & n_z_ucured > 0 ) {
      beta0 <- theta[1]
      betak <- theta[2:(1 + n_z_pcured)]
      lambda <- theta[(1 + n_z_pcured + 1)]
      gamma <- theta[(1 + n_z_pcured + 2)]
      delta <- -theta[(1 + n_z_pcured + 3):(1 + n_z_pcured + 2 + n_z_ucured)]
      pcure <- beta0 + z_pcured %*% betak
      cured <- 1/(1 + exp(-pcure))
      usurv <- (exp(-exp(lambda)*(x)^exp(gamma)))^exp(z_ucured %*% delta)
      uhaz <- exp(gamma)*exp(lambda)*((x)^(exp(gamma) - 1)) * exp(z_ucured %*% delta)
      u_f <- uhaz*usurv
      SurvE <- cured + (1 - cured)*usurv
      cumHazE <- -log(SurvE)

      dpdtheta <- dpdtheta_wei(z_pcured = z_pcured, z_ucured = z_ucured, x = x, theta)
      pt_cure <- pt_cure_wei(z_pcured = z_pcured, z_ucured = z_ucured, x, theta)

      dpdbeta0 <- ifelse(length(z_pcured)==1, (1/pt_cure) * do.call("cbind", dpdtheta)[,1] ,(1/pt_cure) * dpdtheta[,1])
      dpdbetak <- ifelse(length(z_pcured)==1,
                         sweep(as.matrix( do.call("cbind",dpdtheta)[,2:(1 + n_z_pcured)]), MARGIN = 1, 1/pt_cure, '*'),
                         sweep(as.matrix(dpdtheta[,2:(1 + n_z_pcured)]), MARGIN = 1, 1/pt_cure, '*')
      )

      dpdlambda <- ifelse(length(z_pcured)==1,
                          (1/pt_cure) * do.call("cbind",dpdtheta)[,(1 + n_z_pcured + 1)],
                          (1/pt_cure) * dpdtheta[,(1 + n_z_pcured + 1)])

      dpdtheta<-  ifelse(length(z_pcured)==1,
                         do.call("cbind",dpdtheta),
                         dpdtheta)

      dpdgamma <- ifelse(length(z_pcured)==1,
                         (1/pt_cure) * dpdtheta,
                         (1/pt_cure) * dpdtheta[,(1 + n_z_pcured + 2)] )

      dpddelta <- ifelse(length(z_pcured)==1,
                         sweep(as.matrix(dpdtheta),
                               MARGIN = 1, 1 /
                                 pt_cure, '*'),
                         sweep(as.matrix(dpdtheta[, (1 + n_z_pcured + 3):(1 + n_z_pcured + 2 + n_z_ucured)]),
                               MARGIN = 1, 1 /
                                 pt_cure, '*')
                         )



      derivees_partielles <- list(dpdbeta0 = dpdbeta0,
                                  dpdbetak = dpdbetak,
                                  dpdlambda = dpdlambda,
                                  dpdgamma = dpdgamma,
                                  dpddelta = dpddelta)

    } else if (n_z_pcured > 0 & n_z_ucured == 0 ) {
      beta0 <- theta[1]
      betak <- theta[2:(1 + n_z_pcured)]
      lambda <- theta[(1 + n_z_pcured + 1)]
      gamma <- theta[(1 + n_z_pcured + 2)]
      delta <- -theta[(1 + n_z_pcured + 3):(1 + n_z_pcured + 2 + n_z_ucured)]
      pcure <- beta0 + z_pcured %*% betak
      cured <- 1/(1 + exp(-pcure))
      usurv <- (exp(-exp(lambda)*(x)^exp(gamma)))
      uhaz <- exp(gamma)*exp(lambda)*((x)^(exp(gamma) - 1))
      u_f <- uhaz*usurv
      SurvE <- cured + (1 - cured)*usurv
      cumHazE <- -log(SurvE)


      dpdtheta <- dpdtheta_wei(z_pcured = z_pcured, z_ucured = z_ucured, x = x, theta)
      pt_cure <- pt_cure_wei(z_pcured = z_pcured, z_ucured = z_ucured, x, theta)
      dpdbeta0 <- (1/pt_cure) * dpdtheta[,1]
      dpdbetak <- sweep(as.matrix(dpdtheta[,2:(1 + n_z_pcured)]), MARGIN = 1, 1/pt_cure, '*')

      dpdlambda <- (1/pt_cure) * dpdtheta[,(1 + n_z_pcured + 1)]

      dpdgamma <- (1/pt_cure) * dpdtheta[,(1 + n_z_pcured + 2)]


      derivees_partielles <- list(dpdbeta0 = dpdbeta0,
                                  dpdbetak = dpdbetak,
                                  dpdlambda = dpdlambda,
                                  dpdgamma = dpdgamma)

    } else if (n_z_pcured == 0 & n_z_ucured > 0 ) {
      beta0 <- theta[1]
      lambda <- theta[(1 + n_z_pcured + 1)]
      gamma <- theta[(1 + n_z_pcured + 2)]
      delta <- -theta[(1 + n_z_pcured + 3):(1 + n_z_pcured + 2 + n_z_ucured)]
      pcure <- beta0
      cured <- 1/(1 + exp(-pcure))
      usurv <- (exp(-exp(lambda)*(x)^exp(gamma)))^exp(z_ucured %*% delta)
      uhaz <- exp(gamma)*exp(lambda)*((x)^(exp(gamma) - 1)) * exp(z_ucured %*% delta)
      u_f <- uhaz*usurv
      SurvE <- cured + (1 - cured)*usurv
      cumHazE <- -log(SurvE)



      dpdtheta <- dpdtheta_wei(z_pcured = z_pcured, z_ucured = z_ucured, x = x, theta)
      pt_cure <- pt_cure_wei(z_pcured = z_pcured, z_ucured = z_ucured, x, theta)
      dpdbeta0 <- (1/pt_cure) * dpdtheta[,1]
      dpdlambda <- (1/pt_cure) * dpdtheta[,(1 + n_z_pcured + 1)]

      dpdgamma <- (1/pt_cure) * dpdtheta[,(1 + n_z_pcured + 2)]

      dpddelta <- sweep(as.matrix(dpdtheta[,(1 + n_z_pcured + 3):(1 + n_z_pcured + 2 + n_z_ucured)]), MARGIN = 1, 1/pt_cure, '*')



      derivees_partielles <- list(dpdbeta0 = dpdbeta0,
                                  dpdlambda = dpdlambda,
                                  dpdgamma = dpdgamma,
                                  dpddelta = dpddelta)




    } else if (n_z_pcured == 0 & n_z_ucured == 0 ) {
      beta0 <- theta[1]
      lambda <- theta[2]
      gamma <- theta[3]
      pcure <- beta0
      cured <- 1/(1 + exp(-pcure))
      usurv <- (exp(-exp(lambda)*(x)^exp(gamma)))
      uhaz <- exp(gamma)*exp(lambda)*((x)^(exp(gamma) - 1))
      u_f <- uhaz*usurv
      SurvE <- cured + (1 - cured)*usurv
      cumHazE <- -log(SurvE)


      dpdtheta <- dpdtheta_wei(z_pcured = z_pcured, z_ucured = z_ucured, x = x, theta)
      pt_cure <- pt_cure_wei(z_pcured = z_pcured, z_ucured = z_ucured, x, theta)
      dpdbeta0 <- (1 / pt_cure) * dpdtheta$dpdbeta0
      dpdlambda <-
        (1 / pt_cure) * dpdtheta$dpdlambda
      dpdgamma <-
        (1 / pt_cure) * dpdtheta$dpdgamma

      derivees_partielles <- list(dpdbeta0 = dpdbeta0,
                                  dpdlambda = dpdlambda,
                                  dpdgamma = dpdgamma)


    }




    return(derivees_partielles)
  }
