#' @title pt_cure_ic_noDM function
#' @description Variance of p(t) without delta method
#' @param x fit ouput from curesurv
#' @param z_pcured covariates
#' @param t time
#' @param level level of confidence
#' @param theta estimated parameters


pt_cure_ic_noDM = function(x, z_pcured, t, level=0.975, theta)
{
  # IC = p(t) +/- z * sqrt(var(theta))

  z <- stats::qnorm(level) # Quantile d'ordre 1-alpha/2 d'une loi N(0,1) où alpha=0.05

  # Calcul de la borne inf de l'intervalle de confiance de p(t)

  # borne_inf <- sapply(1:length(t),
  #                     function(i)
  #                     {
  #                       b_inf <- pt_cure(z_pcured, t[i], theta) -
  #                         z * sqrt(var(pt_cure(z_pcured, t, theta)))/length(t)
  #                       return(b_inf)
  #                     })
  #
  # # Calcul de la borne sup de l'intervalle de confiance de p(t)
  #
  # borne_sup <- sapply(1:length(t),
  #                     function(i)
  #                     {
  #                       b_sup <- pt_cure(z_pcured, t[i], theta) +
  #                         z * sqrt(var(pt_cure(z_pcured, t, theta)))/length(t)
  #                       return(b_sup)
  #                     })

  borne_inf <-  x$pt_cure - z * sqrt(var(x$pt_cure))
  borne_sup <-  x$pt_cure + z * sqrt(var(x$pt_cure))


  IC <- list(t = t,
             borne_inf = borne_inf,
             borne_sup = borne_sup)

  return(IC)

}
