
varpcured <- function(newdata, object, vartheta) {
  if (!inherits(object, "curesurv"))
    stop("Primary argument much be a curesurv object")
  Call <- match.call()
  newcall <- Call[c(1, match(c("newdata"),
                             names(Call), nomatch = 0))]
  names(newcall)[2] <- "data"
  Terms <- newcall$formula <- object$Terms
  newcall[[1L]] <- quote(stats::model.frame)
  m_eval <- eval(newcall, parent.frame())
  event <- stats::model.extract(m_eval, "response")[, "status"]
  time <- stats::model.extract(m_eval, "response")[, "time"]
  myvarnames <- colnames(stats::model.matrix(Terms, m_eval)[,-1, drop = FALSE])
  z_alpha_id <- which(stringr::str_detect(c(myvarnames),
                                          pattern = "z_alpha"))
  z_tau_id <- which(stringr::str_detect(c(myvarnames),
                                        pattern = "z_tau"))

  if (length(z_alpha_id) > 0) {
    z_alpha <- as.data.frame(
      stats::model.matrix(Terms, m_eval)[,-1, drop = FALSE][, c(z_alpha_id)])
    colnames(z_alpha) <- c(stringr::str_remove(myvarnames[c(z_alpha_id)], "z_alpha"))
    z_alpha <- as.matrix(z_alpha)
  }else{
    z_alpha <- stats::model.matrix(Terms, m_eval)[,-1, drop = FALSE]
    if (length(z_tau_id) > 0)
      colnames(z_alpha) <- c(stringr::str_remove(myvarnames,"z_tau"))
  }

  if (length(z_tau_id) > 0) {
    z_tau <- as.data.frame(
      stats::model.matrix(Terms, m_eval)[,-1, drop = FALSE][, c(z_tau_id)])
    colnames(z_tau) <- c(stringr::str_remove(myvarnames[c(z_tau_id)],"z_tau"))
    z_tau <- as.matrix(z_tau)

  }else{
    z_tau <- stats::model.matrix(Terms, m_eval)[,-1, drop = FALSE]
    if (length(z_alpha_id) > 0)
      colnames(z_tau) <- c(stringr::str_remove(myvarnames, "z_alpha"))

  }


  # if (is.null(z_tau) | is.null(z_alpha) ) {
  #   z_tau <- object$z_tau
  #   z_alpha <- object$z_alpha
  # }
  # theta <- object$coefficients
  Dpcured <- dpcuredtheta(newdata, object)
  varpcured_res <- Dpcured %*% vartheta %*% t(Dpcured)
  return(varpcured_res)
}
