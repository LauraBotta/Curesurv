fit.opt.maxim.frailty_hp_adtneh2 <- function(x = x,
                                 d = d,
                                 z_tau = z_tau,
                                 z_alpha = z_alpha,
                                 theta_init = theta_init,
                                 theta_lower = theta_lower,
                                 theta_upper = theta_upper,
                                 pophaz = pophaz,
                                 cumpophaz = cumpophaz,
                                 method_opt = method_opt,
                                 pophaz.alpha = pophaz.alpha,
                                 maxit_opt = maxit_opt,
                                 gradient = gradient,
                                 hessian_varcov = hessian_varcov,
                                 ncoor_des = ncoor_des,
                                 optim_func = optim_func,
                                 iter_eps = iter_eps,
                                 nproc = nproc,
                                 clustertype = clustertype,
                                 trace = trace,
                                 optim_fixed = optim_fixed,
                                 optimizer = optimizer) {

  fixed <- optim_fixed
  theta <- theta2 <- theta_init
  n_z_tau <- ncol(z_tau)
  n_z_alpha <- ncol(z_alpha)
  n_z_tau_ad <- n_z_tau - 1
  n_z_alpha_ad <- n_z_alpha - 1
  pophaz.alpha <- TRUE

    if (n_z_tau >= 1 & n_z_alpha >= 1) {
      names(theta) <- c('alpha0',
                        paste('alpha', 1:n_z_alpha, colnames(z_alpha) ,sep = "_"),
                        'beta',
                        'tau0',
                        paste('tau', 1:n_z_tau, colnames(z_tau), sep = "_"),
                        'mu', 'psi')

      names(theta2) <- c('alpha0',
                        paste('alpha', 1:n_z_alpha
                              ,sep = "_"),
                        'beta',
                        'tau0',
                        paste('tau', 1:n_z_tau, sep = "_"),
                        'mu', 'psi')


    } else if (n_z_tau >= 1 & n_z_alpha == 0) {
      names(theta) <- c('alpha0',
                        'beta',
                        'tau0',
                        paste('tau', 1:n_z_tau, colnames(z_tau), sep = "_"),
                        'mu', 'psi')

      names(theta2) <- c('alpha0',
                        'beta',
                        'tau0',
                        paste('tau', 1:n_z_tau, sep = "_"),
                        'mu', 'psi')


    } else if (n_z_tau == 0 & n_z_alpha >= 1) {
      names(theta) <- c('alpha0',
                        paste('alpha', 1:n_z_alpha, colnames(z_alpha) ,sep = "_"),
                        'beta',
                        'tau0',
                        'mu', 'psi')

      names(theta2) <- c('alpha0',
                        paste('alpha', 1:n_z_alpha ,sep = "_"),
                        'beta',
                        'tau0',
                        'mu', 'psi')


    }
    else if (n_z_tau == 0 & n_z_alpha == 0) {
      names(theta) <- names(theta2)  <- c('alpha0','beta','tau0', 'mu', 'psi')
    }




  adtneh_SDtheta <- function(theta) {
    n_z_tau <- ncol(z_tau)
    n_z_alpha <- ncol(z_alpha)
    n_z_tau_ad <- n_z_tau - 1
    n_z_alpha_ad <- n_z_alpha - 1
    alpha0 <- (theta[1])
    if (n_z_tau > 0 & n_z_alpha > 0) {


      alpha_k <- theta[2:(n_z_alpha + 1)]
      beta <- (theta[n_z_alpha + 2])
      tau0 <- theta[n_z_alpha + 2 + 1]
      tau_z <- theta[(n_z_alpha + 2 + 1 + 1):(n_z_alpha + 2 + n_z_tau + 1)]

      alpha <- (alpha0 + z_alpha %*% alpha_k)
      # alpha <- alpha*(alpha > 0) + 200*(alpha <= 0)
      tau <- (tau0 + z_tau %*% tau_z)
      # tau <- tau*(tau > 0) + 9999*(tau <= 0)
      u <- x / (tau)
    } else if (n_z_tau > 0 & n_z_alpha == 0)
    {
      beta <- (theta[2])
      tau0 <- theta[2 + 1]
      tau_z <- theta[(2 + 1 + 1):(2 + n_z_tau + 1)]

      alpha <- (alpha0)
      # alpha <- alpha*(alpha > 0) + 200*(alpha <= 0)
      tau <- (tau0 + z_tau %*% tau_z)
      # tau <- tau*(tau > 0) + 9999*(tau <= 0)
      u <- x / (tau)

    } else if (n_z_tau == 0 & n_z_alpha > 0) {

      alpha_k <- theta[2:(n_z_alpha + 1)]
      beta <- (theta[n_z_alpha + 2])
      tau0 <- theta[n_z_alpha + 2 + 1]
      alpha <- (alpha0 + z_alpha %*% alpha_k)
      # alpha <- alpha*(alpha > 0) + 200*(alpha <= 0)
      tau <- (tau0)
      # tau <- tau*(tau > 0) + 9999*(tau <= 0)
      u <- x / (tau)
    } else
      if (n_z_tau == 0 & n_z_alpha == 0) {
        beta <- (theta[2])
        tau0 <- theta[3]
          alpha <- (alpha0)
          # alpha <- alpha*(alpha > 0) + 200*(alpha <= 0)
        tau <- (tau0)
        # tau <- tau*(tau > 0) + 9999*(tau <= 0)
        u <- x / (tau)
        beta2 <- beta
      }




    n <- length(x)
    npar <- length(theta)
    A <- matrix(0, n, npar)



    # u <- u*(u < 1)

    u <- ifelse(u < 1, u, (1 - 1e-10))

    dLalpha <- sapply(1:length(u),
                      function(i) {
                        u <- u[i]
                        if (n_z_tau == 0 & n_z_alpha == 0) {
                          alpha <- alpha
                        }else if (n_z_tau > 0 & n_z_alpha == 0) {
                          alpha <- alpha
                        }else if (n_z_tau > 0 & n_z_alpha > 0) {
                          alpha <- alpha[i]
                        }else if (n_z_tau == 0 & n_z_alpha > 0) {
                          alpha <- alpha[i]
                        }

                        func_Lalpha <- function(y) {
                          c(y^(alpha - 1)*(1 - y)^(beta - 1)*log(y))
                        }
                        integrandval <- stats::integrate(func_Lalpha,
                                                  0, u)$value
                        return(integrandval)
                      })



    dLbeta <- sapply(1:length(u),
                     function(i) {
                       u <- u[i]
                       if (n_z_tau == 0 & n_z_alpha == 0) {
                         alpha <- alpha
                       }else if (n_z_tau > 0 & n_z_alpha == 0) {
                         alpha <- alpha
                       }else if (n_z_tau > 0 & n_z_alpha > 0) {
                         alpha <- alpha[i]
                       }else if (n_z_tau == 0 & n_z_alpha > 0) {
                         alpha <- alpha[i]
                       }
                       func_Lbeta <- function(y) {
                         c(y^(alpha - 1)*(1 - y)^(beta - 1)*log(1 - y))
                       }
                       integrandvalb <- stats::integrate(func_Lbeta,
                                                  0, u)$value
                       return(integrandvalb)
                     })


    dLtau <- cumLexc_ad2(z_tau,
                        z_alpha,
                        x = x,
                        theta)/tau - stats::dbeta(u,
                                           alpha + 1,
                                           beta) * beta(alpha + 1,
                                                        beta)
    # browser()

    A[,1] <-  ((d * c(log(u))*lexc_ad2(z_tau,
                                     z_alpha,
                                     x = x,
                                     theta)) / (pophaz +
                                                  lexc_ad2(z_tau,
                                                          z_alpha,
                                                          x = x,
                                                          theta))) -
      tau * dLalpha
      #dalpha0


    if (n_z_tau > 0 & n_z_alpha > 0) {
      A[,2:(n_z_alpha + 1)] <-  ((z_alpha * c(d *
                                               c(log(u)) *
                                               lexc_ad2(z_tau,
                                                       z_alpha,
                                                       x = x,
                                                       theta))) /
        c(pophaz + lexc_ad2(z_tau,
                            z_alpha,
                            x = x,
                            theta))) - z_alpha * c(tau * dLalpha) #dalphaK

      log_1_u <- ifelse(is.na(log(1 - u)),
                        log(1e-19),
                        log(1 - u))

      A[,(1 + n_z_alpha + 1)] <- ((d * c(log_1_u) *
                                    lexc_ad2(z_tau,
                                            z_alpha,
                                            x = x,
                                            theta)) /
        (pophaz + lexc_ad2(z_tau,
                           z_alpha,
                           x = x,
                           theta))) - tau * dLbeta #dbeta

      A[,(n_z_alpha + 3)] <- ((d * (1/tau) * (2 - alpha - beta +
                                               (beta - 1/1 - u)) *
                                lexc_ad2(z_tau,
                                        z_alpha,
                                        x = x,
                                        theta)) /
        (pophaz + lexc_ad2(z_tau,
                           z_alpha,
                           x = x,
                           theta))) - dLtau
      #dtau0

      seq_tauz <- (n_z_alpha + 4):(n_z_alpha + n_z_tau + 3)

      A[,seq_tauz] <- ((d * (z_tau/c(tau)) * c(2 - alpha - beta +
                                                (beta - 1/1 - u)) *
                         c(lexc_ad2(z_tau,
                                   z_alpha,
                                   x = x,
                                   theta))) /
        c(pophaz +
            lexc_ad2(z_tau,
                    z_alpha,
                    x = x,
                    theta))) - z_tau * c(dLtau)
      #dtauz
    } else if (n_z_tau > 0 & n_z_alpha == 0) {

      log_1_u <- ifelse(is.na(log(1 - u)),
                        log(1e-19),
                        log(1 - u))
      A[,2] <- ((d * c(log_1_u) *
                  lexc_ad2(z_tau,
                          z_alpha,
                          x = x,
                          theta)) /
        (pophaz + lexc_ad2(z_tau,
                           z_alpha,
                           x = x,
                           theta))) -  tau * dLbeta#dbeta

      A[,3] <- ((d * (1/tau) * c(2 - alpha - beta +
                                  (beta - 1/1 - u)) *
                  lexc_ad2(z_tau,
                          z_alpha,
                          x = x,
                          theta)) /
        (pophaz + lexc_ad2(z_tau,
                           z_alpha,
                           x = x,
                           theta))) - dLtau
      #dtau0

      seq_tauz <- (2 + 1 + 1):(2 + n_z_tau + 1)

      A[,seq_tauz] <- (d * (z_tau/c(tau)) * c(2 - alpha - beta +
                                                (beta - 1/1 - u)) *
                         c(lexc_ad2(z_tau,
                                   z_alpha,
                                   x = x,
                                   theta))) /
        c(pophaz +
            lexc_ad2(z_tau,
                    z_alpha,
                    x = x,
                    theta)) - z_tau * c(dLtau)
      #dtauz


    } else if (n_z_tau == 0 & n_z_alpha > 0) {


      A[,2:(n_z_alpha + 1)] <-  ((d * z_alpha *
                                   c(log(u)) *
                                   c(lexc_ad2(z_tau,
                                             z_alpha,
                                             x = x,
                                             theta))) /
        c(pophaz + lexc_ad2(z_tau,
                            z_alpha,
                            x = x,
                            theta))) -  z_alpha * c(tau * dLalpha) #dalphaK
      log_1_u <- ifelse(is.na(log(1 - u)),
                        log(1e-19),
                        log(1 - u))
      A[,(1 + n_z_alpha + 1)] <- ((d * c(log_1_u) *
                                    lexc_ad2(z_tau,
                                            z_alpha,
                                            x = x,
                                            theta)) /
        (pophaz + lexc_ad2(z_tau,
                           z_alpha,
                           x = x,
                           theta))) -  tau * dLbeta#dbeta

      A[,(n_z_alpha + 3)] <- ((d * (1/tau) * (2 - alpha - beta +
                                               (beta - 1/1 - u)) *
                                lexc_ad2(z_tau,
                                        z_alpha,
                                        x = x,
                                        theta)) /
        (pophaz + lexc_ad2(z_tau,
                           z_alpha,
                           x = x,
                           theta))) - dLtau
      #dtau0

    } else if (n_z_tau == 0 & n_z_alpha == 0) {


      A[,2] <- ((d * c(log(1 - u)) *
                  lexc_ad2(z_tau,
                          z_alpha,
                          x = x,
                          theta)) /
        (pophaz + lexc_ad2(z_tau,
                           z_alpha,
                           x = x,
                           theta))) - tau * dLbeta #dbeta

      A[, 3] <- ((d * (1/tau) * (2 - alpha - beta +
                                  (beta - 1/1 - u)) *
                   lexc_ad2(z_tau,
                           z_alpha,
                           x = x,
                           theta)) /
        (pophaz + lexc_ad2(z_tau,
                           z_alpha,
                           x = x,
                           theta))) - dLtau
      #dtau0
    }

    model_grad <- colSums(A)
    if (anyNA(model_grad)) {
      idna <- which(is.na(model_grad))
      model_grad[idna] <- -1 - 1.0e-19

    }
    return(model_grad)
  }

#
#   ll_fn <- function(theta) {
#     browser()
#     if (anyNA(theta))
#       return(Inf)
#     if (pophaz.alpha) {
#       alpha_pophaz <- matrix(1, ncol = 1, nrow = length(pophaz)) %*%
#         theta[n_z_alpha + 2 + n_z_tau + 1 + 1]
#     }else{
#       alpha_pophaz <- matrix(1, ncol = 1, nrow = length(pophaz)) %*% 0
#     }
#
#
#     sum_minusloklik <- -sum(d * log(exp(alpha) * pophaz +
#                                       lexc_ad2(z_tau, z_alpha, x, theta)) -
#                               cumlexc_ad22(z_tau, z_alpha, x, theta) -
#                               cumpophaz * exp(alpha))
#     if (anyNA(sum_minusloklik)) {
#       return(Inf)
#     } else {
#       return(sum_minusloklik)
#     }
#
#   }





  frail_adtneh_ll_fn <- function(alpha0 = NULL,
                           alpha_k = NULL,
                           beta = NULL,
                           tau0 = NULL,
                           tau_z = NULL,
                           alpha = NULL,
                           mu = NULL,
                           psi = NULL) {


    if (n_z_alpha == 0 & n_z_tau == 0) {
      theta <- c(alpha0, beta, tau0, mu, psi)
    } else if (n_z_alpha > 0 & n_z_tau == 0) {
      theta <- c(alpha0, alpha_k, beta, tau0,  mu, psi)
    }else if (n_z_alpha == 0 & n_z_tau > 0) {
      theta <- c(alpha0, beta, tau0, tau_z,  mu, psi)
    }else if (n_z_alpha > 0 & n_z_tau > 0) {
      theta <- c(alpha0, alpha_k, beta, tau0, tau_z, mu, psi)
    }



    if (anyNA(theta))
      return(1e10)
    if (pophaz.alpha) {
      alpha_pophaz <- matrix(1,
                              ncol = 1,
                              nrow = length(pophaz)) %*%
        theta[n_z_alpha + 2 + n_z_tau + 1 + 1]
    }else{

      alpha_pophaz <- matrix(1, ncol = 1,
                      nrow = length(pophaz)) %*% 0
    }

    n_z_tau <- ncol(z_tau)
    n_z_alpha <- ncol(z_alpha)
    n_z_tau_ad <- n_z_tau - 1
    n_z_alpha_ad <- n_z_alpha - 1
    alpha0 <- theta[1]

    if (n_z_tau > 0 & n_z_alpha > 0) {
      alpha_k <- theta[2:(n_z_alpha + 1)]
      beta <- (theta[n_z_alpha + 2])
      tau0 <- theta[n_z_alpha + 2 + 1]
      tau_z <- theta[(n_z_alpha + 2 + 1 + 1):(n_z_alpha + 2 + n_z_tau + 1)]
      mu <- theta[n_z_alpha + 2 + n_z_tau + 2]
      psi <- theta[n_z_alpha + 2 + n_z_tau + 3]
      if (any(alpha0 + z_alpha %*% alpha_k <= 0) | any(tau0 + z_tau %*% tau_z <= 0)) {
        sum_minusloklik <- 1e10
      }else {
        lambda_obs <- ((exp(mu) * pophaz) / (1 + exp(psi) * cumpophaz)) +
          lexc_ad2(z_tau, z_alpha, x, theta)

        sum_minusloklik <- -sum(d * log(lambda_obs) -
                                  cumLexc_ad2(z_tau, z_alpha, x, theta) -
                                  c(exp(mu)/exp(psi)) * log(1 + exp(psi) * cumpophaz),
                                na.rm = TRUE)
      }
    }else if (n_z_tau > 0 & n_z_alpha == 0) {
      beta <- (theta[2])
      tau0 <- theta[2 + 1]
      tau_z <- theta[(2 + 1 + 1):(2 + n_z_tau + 1)]
      mu <- theta[2 + n_z_tau + 2]
      psi <- theta[2 + n_z_tau + 3]
      if (any(alpha0  <= 0) | any(tau0 + z_tau %*% tau_z <= 0)) {
        sum_minusloklik <- 1e10
      }else {
        lambda_obs <- ((exp(mu) * pophaz) / (1 + exp(psi) * cumpophaz)) +
          lexc_ad2(z_tau, z_alpha, x, theta)

        sum_minusloklik <- -sum(d * log(lambda_obs) -
                                  cumLexc_ad2(z_tau, z_alpha, x, theta) -
                                  (exp(mu)/exp(psi)) * log(1 + exp(psi) * cumpophaz),
                                na.rm = TRUE)
      }
    }else if (n_z_tau == 0 & n_z_alpha > 0) {
      alpha_k <- theta[2:(n_z_alpha + 1)]
      beta <- (theta[n_z_alpha + 2])
      tau0 <- theta[n_z_alpha + 2 + 1]
      mu <- theta[n_z_alpha + 2 + 2]
      psi <- theta[n_z_alpha + 2 + 3]
      if (any(alpha0 + z_alpha %*% alpha_k <= 0) | tau0  <= 0) {
        sum_minusloklik <- 1e10
      }else {
        lambda_obs <- ((exp(mu) * pophaz) / (1 + exp(psi) * cumpophaz)) +
          lexc_ad2(z_tau, z_alpha, x, theta)
        sum_minusloklik <- -sum(d * log(lambda_obs) -
                                  cumLexc_ad2(z_tau, z_alpha, x, theta) -
                                  (exp(mu)/exp(psi)) * log(1 + exp(psi) * cumpophaz), na.rm = TRUE)
      }
    }else if (n_z_tau == 0 & n_z_alpha == 0) {
      tau0 <- theta[n_z_alpha + 2 + 1]
      beta <- (theta[n_z_alpha + 2])
      mu <- theta[n_z_alpha + 2 + 2]
      psi <- theta[n_z_alpha + 2 + 3]

      if (alpha0  <= 0 | tau0 <= 0) {
        sum_minusloklik <- 1e10
      }else {
        lambda_obs <- ((exp(mu) * pophaz) / (1 + exp(psi) * cumpophaz)) +
          lexc_ad2(z_tau, z_alpha, x, theta)
        sum_minusloklik <- -sum(d * log(lambda_obs) -
                                  cumLexc_ad2(z_tau, z_alpha, x, theta) -
                                  (exp(mu)/exp(psi)) * log(1 + exp(psi) * cumpophaz),
                                na.rm = TRUE)
      }
    }

    if (anyNA(sum_minusloklik)) {
      return(1e10)
    } else {
      return(sum_minusloklik)
    }

  }






  frail_adtneh_ll_fn3 <- function(alpha0 = NULL,
                                  alpha_k = NULL,
                                  beta = NULL,
                                  tau0 = NULL,
                                  tau_z = NULL,
                                  alpha = NULL,
                                  mu = NULL,
                                  psi = NULL) {


    if (n_z_alpha == 0 & n_z_tau == 0) {
      theta <- c(alpha0, beta, tau0, mu, psi)
    } else if (n_z_alpha > 0 & n_z_tau == 0) {
      if (optim_func == "bbmle") {

        alpha_k <- eval(
          parse(text = paste("c(",
                             paste(paste("tau", 1:n_z_tau,
                                         sep = "_"),
                                   collapse = ","),
                             ")", sep = "")))
      }
      theta <- c(alpha0, alpha_k, beta, tau0,  mu, psi)
    }else if (n_z_alpha == 0 & n_z_tau > 0) {
      if (optim_func == "bbmle") {
        tau_z <- eval(
          parse(text = paste("c(",
                             paste(paste("tau", 1:n_z_tau,
                                         sep = "_"),
                                   collapse = ","),
                             ")", sep = "")))
      }
      theta <- c(alpha0, beta, tau0, tau_z,  mu, psi)
    }else if (n_z_alpha > 0 & n_z_tau > 0) {
      if (optim_func == "bbmle") {

        alpha_k <- eval(
          parse(text = paste("c(",
                             paste(paste("tau", 1:n_z_tau,
                                         sep = "_"),
                                   collapse = ","),
                             ")", sep = "")))
        tau_z <- eval(
          parse(text = paste("c(",
                             paste(paste("tau", 1:n_z_tau,
                                         sep = "_"),
                                   collapse = ","),
                             ")", sep = "")))
      }
      theta <- c(alpha0, alpha_k, beta, tau0, tau_z, mu, psi)
    }



    if (anyNA(theta))
      return(1e10)

    alpha_pophaz <- matrix(1,
                            ncol = 1,
                            nrow = length(pophaz)) %*%
      theta[n_z_alpha + 2 + n_z_tau + 1 + 1]


    n_z_tau <- ncol(z_tau)
    n_z_alpha <- ncol(z_alpha)
    n_z_tau_ad <- n_z_tau - 1
    n_z_alpha_ad <- n_z_alpha - 1
    alpha0 <- theta[1]

    if (n_z_tau > 0 & n_z_alpha > 0) {
      alpha_k <- theta[2:(n_z_alpha + 1)]
      beta <- (theta[n_z_alpha + 2])
      tau0 <- theta[n_z_alpha + 2 + 1]
      tau_z <- theta[(n_z_alpha + 2 + 1 + 1):(n_z_alpha + 2 + n_z_tau + 1)]
      mu <- theta[n_z_alpha + 2 + n_z_tau + 2]
      psi <- theta[n_z_alpha + 2 + n_z_tau + 3]
      if (any(alpha0 + z_alpha %*% alpha_k <= 0) | any(tau0 + z_tau %*% tau_z <= 0)) {
        sum_minusloklik <- 1e10
      }else {
        lambda_obs <- ((exp(mu) * pophaz) / (1 + exp(psi) * cumpophaz)) +
          lexc_ad2(z_tau, z_alpha, x, theta)

        sum_minusloklik <- -sum(d * log(lambda_obs) -
                                  cumLexc_ad2(z_tau, z_alpha, x, theta) -
                                  c(exp(mu)/exp(psi)) * log(1 + exp(psi) * cumpophaz),
                                na.rm = TRUE)
      }
    }else if (n_z_tau > 0 & n_z_alpha == 0) {
      beta <- (theta[2])
      tau0 <- theta[2 + 1]
      tau_z <- theta[(2 + 1 + 1):(2 + n_z_tau + 1)]
      mu <- theta[2 + n_z_tau + 2]
      psi <- theta[2 + n_z_tau + 3]
      if (any(alpha0  <= 0) | any(tau0 + z_tau %*% tau_z <= 0)) {
        sum_minusloklik <- 1e10
      }else {
        lambda_obs <- ((exp(mu) * pophaz) / (1 + exp(psi) * cumpophaz)) +
          lexc_ad2(z_tau, z_alpha, x, theta)

        sum_minusloklik <- -sum(d * log(lambda_obs) -
                                  cumLexc_ad2(z_tau, z_alpha, x, theta) -
                                  (exp(mu)/exp(psi)) * log(1 + exp(psi) * cumpophaz),
                                na.rm = TRUE)
      }
    }else if (n_z_tau == 0 & n_z_alpha > 0) {
      alpha_k <- theta[2:(n_z_alpha + 1)]
      beta <- (theta[n_z_alpha + 2])
      tau0 <- theta[n_z_alpha + 2 + 1]
      mu <- theta[n_z_alpha + 2 + 2]
      psi <- theta[n_z_alpha + 2 + 3]
      if (any(alpha0 + z_alpha %*% alpha_k <= 0) | tau0  <= 0) {
        sum_minusloklik <- 1e10
      }else {
        lambda_obs <- ((exp(mu) * pophaz) / (1 + exp(psi) * cumpophaz)) +
          lexc_ad2(z_tau, z_alpha, x, theta)
        sum_minusloklik <- -sum(d * log(lambda_obs) -
                                  cumLexc_ad2(z_tau, z_alpha, x, theta) -
                                  (exp(mu)/exp(psi)) * log(1 + exp(psi) * cumpophaz), na.rm = TRUE)
      }
    }else if (n_z_tau == 0 & n_z_alpha == 0) {
      tau0 <- theta[n_z_alpha + 2 + 1]
      beta <- (theta[n_z_alpha + 2])
      mu <- theta[n_z_alpha + 2 + 2]
      psi <- theta[n_z_alpha + 2 + 3]

      if (alpha0  <= 0 | tau0 <= 0) {
        sum_minusloklik <- 1e10
      }else {
        lambda_obs <- ((exp(mu) * pophaz) / (1 + exp(psi) * cumpophaz)) +
          lexc_ad2(z_tau, z_alpha, x, theta)
        sum_minusloklik <- -sum(d * log(lambda_obs) -
                                  cumLexc_ad2(z_tau, z_alpha, x, theta) -
                                  (exp(mu)/exp(psi)) * log(1 + exp(psi) * cumpophaz),
                                na.rm = TRUE)
      }
    }

    if (anyNA(sum_minusloklik)) {
      return(1e10)
    } else {
      return(sum_minusloklik)
    }

  }








  if (!is.null(theta_lower) && !is.null(theta_upper)) {
    start_val <- gen_start_values(nvalues = 20,
                                  min = theta_lower,
                                  max = theta_upper,
                                  npar = length(theta_init))
  } else if (NCD == "iter") {
    stop("add bounds for initial values")
  }


  if (optim_func == "optim") {
    if (method_opt == "L-BFGS-B") {
      if (gradient) {

        NCD <- ncoor_des

        if (is.null(NCD)) {
          optimized <- stats::optim(par = theta,
                                    fn = frail_adtneh_ll_fn,
                                    gr = adtneh_SDtheta,
                                    method = method_opt,
                                    hessian = TRUE,
                                    lower = theta_lower,
                                    upper = theta_upper,
                                    control = list(maxit = maxit_opt,
                                                   trace = trace,
                                                   REPORT = 500))
        } else if (is.numeric(NCD)) {
          optimized_theta <- try(stats::optim(par = theta,
                                    fn = frail_adtneh_ll_fn,
                                    gr = adtneh_SDtheta,
                                    method = method_opt,
                                    hessian = TRUE,
                                    lower = theta_lower,
                                    upper = theta_upper,
                                    control = list(maxit = maxit_opt,
                                                   trace = trace,
                                                   REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }


          for (j in 1:NCD) {
            print(j)
            cat("cycle =", j, "\n")

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })

              new.val <- try(stats::optim(par = init.cd[i],
                                      fn = tempf,
                                      method = method_opt,
                                      hessian = TRUE,
                                      lower = theta_lower[i],
                                      upper = theta_upper[i],
                                      control = list(
                                        maxit = maxit_opt, trace = trace,
                                        REPORT = 500))$par, TRUE)
              cat("new initial value of parameter number",i,"is equal to:", new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- (theta_lower[i] + theta_upper[i])/2
              }
              init.cd <- replace(init.cd, i,  new.val )
            }
          }

          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(stats::optim(par = initG ,
                                        fn = frail_adtneh_ll_fn,
                                        gr = adtneh_SDtheta,
                                        method = method_opt,
                                        hessian = TRUE,
                                        lower = theta_lower,
                                        upper = theta_upper,
                                        control = list(maxit = maxit_opt,
                                                       trace = trace,
                                                       REPORT = 500)), TRUE)



        }else if ( NCD == "iter") {
          optimized_theta <- try(stats::optim(par = theta,
                                              fn = frail_adtneh_ll_fn,
                                              gr = adtneh_SDtheta,
                                              method = method_opt,
                                              hessian = TRUE,
                                              lower = theta_lower,
                                              upper = theta_upper,
                                              control = list(maxit = maxit_opt,
                                                             trace = trace,
                                                             REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }

          j = 0
          mydiff <- matrix(data = 1,
                           nrow = 10000,
                           ncol = 1)
          loglik_val <- matrix(data = 0,
                               nrow = 10000,
                               ncol = 1)
          theta_val <- matrix(data = 0,
                              nrow = 10000,
                              ncol = length(theta))
          while (abs(mydiff[j + 1, ]) > iter_eps && (j = j + 1) < 10000) {
            print(j)
            cat("cycle =", j, "\n")

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })


              new.valpar <- try(stats::optim(par = init.cd[i],
                                               fn = tempf,
                                               method = method_opt,
                                               hessian = TRUE,
                                               lower = theta_lower[i],
                                               upper = theta_upper[i],
                                               control = list(
                                                 maxit = maxit_opt, trace = trace,
                                                 REPORT = 500)), TRUE)

              new.val <- try(new.valpar$par, TRUE)

              cat("new initial value of parameter number", i,
                  "is equal to:", new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- (theta_lower[i] + theta_upper[i])/2
              }



              init.cd <- replace(init.cd, i,  new.val )

            }
            theta_val[j, ] <-  theta
            theta_val[j + 1, ] <- try(init.cd, TRUE)
            loglik_val[j + 1,] <- try(c(new.valpar$value), TRUE)
            mydiff[j + 1, ] <- try(c(loglik_val[j + 1, ] -
                                       loglik_val[j, ]), TRUE)
            cat("difference between loglikelihood at iter = ",
                j + 1,
                "equal",
                mydiff[j + 1, ],
                ". The j+1 th logliklihood equal",
                loglik_val[j + 1, ],
                ".\n")
            if (abs(loglik_val[(j + 1), ]) == Inf |
                abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                loglik_val[(j + 1), ] > 0) {
              loglik_val[(j + 1), ] = 10000
              mydiff[(j + 1), ]     = 10000
            } else if (abs(loglik_val[(j + 1), ]) == Inf |
                       abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                       loglik_val[(j + 1), ] < 0) {
              loglik_val[(j + 1), ] = -10000
              mydiff[(j + 1), ]     = -10000
            }

            if (j >= 2) {

              par(mfrow = c(1, 2))
              plot(2:(j + 1),
                   loglik_val[2:(j + 1),],
                   type = "l",
                   col = 2,
                   ylab = "loglik",
                   xlab = "iter")
              graphics::grid()
              plot(2:(j + 1),
                   abs(mydiff[2:(j + 1),]),
                   type = "l",
                   col = "green",
                   ylab = "loglik_abs_diff",
                   xlab = "iter")
              graphics::grid()
              par(mfrow = c(1, 1))
            }

          }


          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(stats::optim(par = initG ,
                                          fn = frail_adtneh_ll_fn,
                                          gr = adtneh_SDtheta,
                                          method = method_opt,
                                          hessian = TRUE,
                                          lower = theta_lower,
                                          upper = theta_upper,
                                          control = list(maxit = maxit_opt,
                                                         trace = trace,
                                                         REPORT = 500)), TRUE)



        }

      }else {
        NCD <- ncoor_des

        if (is.null(NCD)) {
          optimized <- stats::optim(par = theta ,
                                    fn = frail_adtneh_ll_fn,
                                    method = method_opt,
                                    hessian = TRUE,
                                    lower = theta_lower,
                                    upper = theta_upper,
                                    control = list(maxit = maxit_opt,
                                                   trace = trace,
                                                   REPORT = 500))

        } else if (is.numeric(NCD)) {

          optimized_theta <- try(stats::optim(par = theta,
                                              fn = frail_adtneh_ll_fn,
                                              method = method_opt,
                                              hessian = TRUE,
                                              lower = theta_lower,
                                              upper = theta_upper,
                                              control = list(maxit = maxit_opt,
                                                             trace = trace,
                                                             REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }
          for (j in 1:NCD) {
            print(j)
            cat("cycle =", j, "\n")

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })

              new.val <- try(stats::optim(par = init.cd[i],
                                      fn = tempf,
                                      method = method_opt,
                                      hessian = TRUE,
                                      lower = theta_lower[i],
                                      upper = theta_upper[i],
                                      control = list(
                                        maxit = maxit_opt, trace = trace,
                                        REPORT = 500))$par, TRUE)
              cat("new initial value of parameter number",i,"is equal to:",new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- (theta_lower[i] + theta_upper[i])/2
              }

              init.cd <- replace(init.cd, i,  new.val )
            }
          }

          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(stats::optim(par = initG ,
                                        fn = frail_adtneh_ll_fn,
                                        method = method_opt,
                                        hessian = TRUE,
                                        lower = theta_lower,
                                        upper = theta_upper,
                                        control = list(maxit = maxit_opt,
                                                       trace = trace,
                                                       REPORT = 500)), TRUE)

        } else if (NCD == "iter") {
          optimized_theta <- try(stats::optim(par = theta,
                                              fn = frail_adtneh_ll_fn,
                                              gr = adtneh_SDtheta,
                                              method = method_opt,
                                              hessian = TRUE,
                                              lower = theta_lower,
                                              upper = theta_upper,
                                              control = list(maxit = maxit_opt,
                                                             trace = trace,
                                                             REPORT = 500))$par,
                                 TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }

          j = 0
          mydiff <- matrix(data = 1,
                           nrow = 10000,
                           ncol = 1)
          loglik_val <- matrix(data = 0,
                               nrow = 10000,
                               ncol = 1)
          theta_val <- matrix(data = 0,
                              nrow = 10000,
                              ncol = length(theta))
          while (abs(mydiff[j + 1, ]) > iter_eps && (j = j + 1) < 10000) {
            print(j)
            cat("cycle =", j, "\n")

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })


              new.valpar <- try(stats::optim(par = init.cd[i],
                                               fn = tempf,
                                               method = method_opt,
                                               hessian = TRUE,
                                               lower = theta_lower[i],
                                               upper = theta_upper[i],
                                               control = list(
                                                 maxit = maxit_opt, trace = trace,
                                                 REPORT = 500)), TRUE)

              new.val <- try(new.valpar$par, TRUE)

              cat("new initial value of parameter number",i,"is equal to:",new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- (theta_lower[i] + theta_upper[i])/2
              }



              init.cd <- replace(init.cd, i,  new.val )

            }
            theta_val[j, ] <-  theta
            theta_val[j + 1, ] <- try(init.cd, TRUE)
            loglik_val[j + 1,] <- try(c(new.valpar$value), TRUE)
            mydiff[j + 1, ] <- try(c(loglik_val[j + 1, ] -
                                       loglik_val[j, ]), TRUE)
            cat("difference between loglikelihood at iter = ",
                j + 1,
                "equal",
                mydiff[j + 1, ],
                ". The j+1 th logliklihood equal",
                loglik_val[j + 1, ],
                ".\n")
            if (abs(loglik_val[(j + 1), ]) == Inf |
                abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                loglik_val[(j + 1), ] > 0) {
              loglik_val[(j + 1), ] = 10000
              mydiff[(j + 1), ]     = 10000
            } else if (abs(loglik_val[(j + 1), ]) == Inf |
                       abs(loglik_val[(j + 1), ]) == .Machine$double.xmax  &
                       loglik_val[(j + 1), ] < 0) {
              loglik_val[(j + 1), ] = -10000
              mydiff[(j + 1), ]     = -10000
            }

            if (j >= 2) {
              par(mfrow = c(1, 2))
              plot(2:(j + 1),
                   loglik_val[2:(j + 1),],
                   type = "l",
                   col = 2,
                   ylab = "loglik",
                   xlab = "iter")
              graphics::grid()
              plot(2:(j + 1),
                   abs(mydiff[2:(j + 1),]),
                   type = "l",
                   col = "green",
                   ylab = "loglik_abs_diff",
                   xlab = "iter")
              graphics::grid()
              par(mfrow = c(1, 1))
            }

          }


          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(stats::optim(par = initG ,
                                          fn = frail_adtneh_ll_fn,
                                          method = method_opt,
                                          hessian = TRUE,
                                          lower = theta_lower,
                                          upper = theta_upper,
                                          control = list(maxit = maxit_opt,
                                                         trace = trace,
                                                         REPORT = 500)), TRUE)



        }
      }




    } else {
      if (gradient) {
      NCD <- ncoor_des
      if (is.null(NCD)) {
        optimized <- stats::optim(par = theta,
                                  fn = frail_adtneh_ll_fn,
                                  gr = adtneh_SDtheta,
                                  method = method_opt,
                                  hessian = TRUE,
                                  control = list(pgtol = 1e-15,
                                                 maxit = maxit_opt,
                                                 trace = trace,
                                                 REPORT = 500))
      } else if (is.numeric(NCD)) {
        optimized_theta <- try(stats::optim(par = theta,
                                            fn = frail_adtneh_ll_fn,
                                            gr = adtneh_SDtheta,
                                            method = method_opt,
                                            hessian = TRUE,
                                            lower = theta_lower,
                                            upper = theta_upper,
                                            control = list(maxit = maxit_opt,
                                                           trace = trace,
                                                           REPORT = 500))$par, TRUE)

        if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
          init.cd <- theta
        }  else {
          init.cd <- optimized_theta
        }


        for (j in 1:NCD) {
          print(j)
          cat("cycle =", j, "\n")
          for (i in 1:length(init.cd)) {
            tempf <- Vectorize(function(par){
              val <- replace(init.cd, i, par)
              return(frail_adtneh_ll_fn(val))
            })

            new.val <- try(stats::optim(par = init.cd[i],
                                    fn = tempf,
                                    method = method_opt,
                                    control = list(pgtol = 1e-15,
                                                   maxit = maxit_opt,
                                                   trace = trace,
                                                   REPORT = 500))$par, TRUE)
            cat("new initial value of parameter number",i,"is equal to:",new.val)
            cat("\n")
            if (anyNA(new.val) | inherits(new.val, "try-error")) {
              new.val <- init.cd[i] + 1
            }
            init.cd <- replace(init.cd, i,  new.val )
          }
        }

        if (any(is.na(init.cd))) {
          initG <- theta
        }  else {
          initG <- init.cd
        }

        optimized <- try(stats::optim(par = initG ,
                                      fn = frail_adtneh_ll_fn,
                                      gr = adtneh_SDtheta,
                                      method = method_opt,
                                      hessian = TRUE,
                                      control = list(pgtol = 1e-15,
                                                     maxit = maxit_opt,
                                                     trace = trace,
                                                     REPORT = 500)), TRUE)




      } else if (NCD == "iter") {
        optimized_theta <- try(stats::optim(par = theta,
                                            fn = frail_adtneh_ll_fn,
                                            gr = adtneh_SDtheta,
                                            method = method_opt,
                                            hessian = TRUE,
                                            lower = theta_lower,
                                            upper = theta_upper,
                                            control = list(maxit = maxit_opt,
                                                           trace = trace,
                                                           REPORT = 500))$par, TRUE)

        if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
          init.cd <- theta
        }  else {
          init.cd <- optimized_theta
        }

        j = 0
        mydiff <- matrix(data = 1,
                         nrow = 10000,
                         ncol = 1)
        loglik_val <- matrix(data = 0,
                             nrow = 10000,
                             ncol = 1)
        theta_val <- matrix(data = 0,
                            nrow = 10000,
                            ncol = length(theta))
        while (abs(mydiff[j + 1, ]) > iter_eps && (j = j + 1) < 10000) {
          print(j)
          cat("cycle =", j, "\n")

          for (i in 1:length(init.cd)) {
            tempf <- Vectorize(function(par){
              val <- replace(init.cd, i, par)
              return(frail_adtneh_ll_fn(val))
            })


            new.valpar <- try(optimx::optimr(par = init.cd[i],
                                             fn = tempf,
                                             method = method_opt,
                                             hessian = TRUE,
                                             control = list(
                                               maxit = maxit_opt, trace = trace,
                                               REPORT = 500)), TRUE)

            new.val <- try(new.valpar$par, TRUE)

            cat("new initial value of parameter number",i,"is equal to:",new.val)
            cat("\n")
            if (anyNA(new.val) | inherits(new.val, "try-error")) {
              new.val <- init.cd[i] + 1
            }



            init.cd <- replace(init.cd, i,  new.val )

          }
          theta_val[j, ] <-  theta
          theta_val[j + 1, ] <- try(init.cd, TRUE)
          loglik_val[j + 1,] <- try(c(new.valpar$value), TRUE)
          mydiff[j + 1, ] <- try(c(loglik_val[j + 1, ] -
                                     loglik_val[j, ]), TRUE)
          cat("difference between loglikelihood at iter = ",
              j + 1,
              "equal",
              mydiff[j + 1, ],
              ". The j+1 th logliklihood equal",
              loglik_val[j + 1, ],
              ".\n")

          if (abs(loglik_val[(j + 1), ]) == Inf  |
              abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
              loglik_val[(j + 1), ] > 0) {
            loglik_val[(j + 1), ] = 10000
            mydiff[(j + 1), ]     = 10000
          } else if (abs(loglik_val[(j + 1), ]) == Inf |
                     abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                     loglik_val[(j + 1), ] < 0) {
            loglik_val[(j + 1), ] = -10000
            mydiff[(j + 1), ]     = -10000
          }

          if (j >= 2) {
          par(mfrow = c(1, 2))
          plot(2:(j + 1),
               loglik_val[2:(j + 1),],
               type = "l",
               col = 2,
               ylab = "loglik",
               xlab = "iter")
          graphics::grid()
          plot(2:(j + 1),
               abs(mydiff[2:(j + 1),]),
               type = "l",
               col = "green",
               ylab = "loglik_abs_diff",
               xlab = "iter")
          graphics::grid()
          par(mfrow = c(1, 1))
          }
        }


        if (any(is.na(init.cd))) {
          initG <- theta
        }  else {
          initG <- init.cd
        }

        optimized <- try(optimx::optimr(par = initG ,
                                        fn = frail_adtneh_ll_fn,
                                        gr = adtneh_SDtheta,
                                        method = method_opt,
                                        hessian = TRUE,
                                        control = list(maxit = maxit_opt,
                                                       trace = trace,
                                                       REPORT = 500)), TRUE)


      }
    }
      else{

        NCD <- ncoor_des
        if (is.null(NCD)) {
          optimized <- stats::optim(par = theta,
                                    fn = frail_adtneh_ll_fn,
                                    method = method_opt,
                                    control = list(pgtol = 1e-15,
                                                   maxit = maxit_opt,
                                                   trace = trace,
                                                   REPORT = 500))
        } else if (is.numeric(NCD)) {
          optimized_theta <- try(stats::optim(par = theta,
                                              fn = frail_adtneh_ll_fn,
                                              method = method_opt,
                                              hessian = TRUE,
                                              control = list(maxit = maxit_opt,
                                                             trace = trace,
                                                             REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }

          for (j in 1:NCD) {
            print(j)
            cat("cycle =", j, "\n")

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })
              new.val <- try(stats::optim(par = init.cd[i],
                                      fn = tempf,
                                      method = method_opt,
                                      control = list(pgtol = 1e-15,
                                                     maxit = maxit_opt,
                                                     trace = trace,
                                                     REPORT = 500))$par, TRUE)
              cat("new initial value of parameter number",i,"is equal to:",new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- init.cd[i] + 1
              }
              init.cd <- replace(init.cd, i,  new.val )
            }
          }

          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(stats::optim(par = initG ,
                                        fn = frail_adtneh_ll_fn,
                                        method = method_opt,
                                        hessian = TRUE,
                                        control = list(pgtol = 1e-15,
                                                       maxit = maxit_opt,
                                                       trace = trace,
                                                       REPORT = 500)), TRUE)




        } else if ( NCD == "iter") {
          optimized_theta <- try(stats::optim(par = theta,
                                              fn = frail_adtneh_ll_fn,
                                              method = method_opt,
                                              hessian = TRUE,
                                              control = list(maxit = maxit_opt,
                                                             trace = trace,
                                                             REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }

          j = 0
          mydiff <- matrix(data = 1,
                           nrow = 10000,
                           ncol = 1)
          loglik_val <- matrix(data = 0,
                               nrow = 10000,
                               ncol = 1)
          theta_val <- matrix(data = 0,
                              nrow = 10000,
                              ncol = length(theta))
          while (abs(mydiff[j + 1, ]) > iter_eps && (j = j + 1) < 10000) {
            print(j)
            cat("cycle =", j, "\n")

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })


              new.valpar <- try(stats::optim(par = init.cd[i],
                                               fn = tempf,
                                               method = method_opt,
                                               hessian = TRUE,
                                               control = list(
                                                 maxit = maxit_opt, trace = trace,
                                                 REPORT = 500)), TRUE)

              new.val <- try(new.valpar$par, TRUE)

              cat("new initial value of parameter number",i,"is equal to:",new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- init.cd[i] + 1
              }



              init.cd <- replace(init.cd, i,  new.val )

            }
            theta_val[j, ] <-  theta
            theta_val[j + 1, ] <- try(init.cd, TRUE)
            loglik_val[j + 1,] <- try(c(new.valpar$value), TRUE)
            mydiff[j + 1, ] <- try(c(loglik_val[j + 1, ] -
                                       loglik_val[j, ]), TRUE)
            cat("difference between loglikelihood at iter = ",
                j + 1,
                "equal",
                mydiff[j + 1, ],
                ". The j+1 th logliklihood equal",
                loglik_val[j + 1, ],
                ".\n")

            if (abs(loglik_val[(j + 1), ]) == Inf |
                abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                loglik_val[(j + 1), ] > 0) {
              loglik_val[(j + 1), ] = 10000
              mydiff[(j + 1), ]     = 10000
            } else if (abs(loglik_val[(j + 1), ]) == Inf |
                       abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                       loglik_val[(j + 1), ] < 0) {
              loglik_val[(j + 1), ] = -10000
              mydiff[(j + 1), ]     = -10000
            }

            if (j >= 2) {
            par(mfrow = c(1, 2))
            plot(2:(j + 1),
                 loglik_val[2:(j + 1),],
                 type = "l",
                 col = 2,
                 ylab = "loglik",
                 xlab = "iter")
            graphics::grid()
            plot(2:(j + 1),
                 abs(mydiff[2:(j + 1),]),
                 type = "l",
                 col = "green",
                 ylab = "loglik_abs_diff",
                 xlab = "iter")
            graphics::grid()
            par(mfrow = c(1, 1))
            }
          }


          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(stats::optim(par = initG ,
                                          fn = frail_adtneh_ll_fn,
                                          method = method_opt,
                                          hessian = TRUE,
                                          control = list(maxit = maxit_opt,
                                                         trace = trace,
                                                         REPORT = 500)), TRUE)


        }
      }}

  }else if (optim_func == "optimr") {
    if (method_opt == "L-BFGS-B" |
        method_opt == "Rvmmin" |
        method_opt == "Rcgmin" |
        method_opt == "nlminb") {


      if (gradient) {
        NCD <- ncoor_des

        if (is.null(NCD)) {
          optimized <- optimr(par = theta,
                                      fn = frail_adtneh_ll_fn,
                                      gr = adtneh_SDtheta,
                                      method = method_opt,#"L-BFGS-B",
                                      hessian = TRUE,
                                      lower = theta_lower,
                                      upper = theta_upper,
                                      control = list(maxit = maxit_opt,
                                                     trace = trace,
                                                     REPORT = 500))
        }else if (is.numeric(NCD)) {

          optimized_theta <- try(optimx::optimr(par = theta,
                                              fn = frail_adtneh_ll_fn,
                                              gr = adtneh_SDtheta,
                                              method = method_opt,
                                              hessian = TRUE,
                                              lower = theta_lower,
                                              upper = theta_upper,
                                              control = list(maxit = maxit_opt,
                                                             trace = trace,
                                                             REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }

          for (j in 1:NCD) {
            print(j)
            cat("cycle =", j, "\n")
            # temp_adtneh_SDtheta <- Vectorize(function(par){
            #   val <- replace(init.cd, i, par)
            #   return(adtneh_SDtheta(val))
            # })

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })

              new.val <- try(optimx::optimr(par = init.cd[i],
                                            fn = tempf,
                                            method = method_opt,
                                            hessian = TRUE,
                                            lower = theta_lower[i],
                                            upper = theta_upper[i],
                                            control = list(
                                              maxit = maxit_opt, trace = trace,
                                              REPORT = 500))$par, TRUE)
              cat("new initial value of parameter number",i,"is equal to:",new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- (theta_lower[i] + theta_upper[i])/2
              }
              init.cd <- replace(init.cd, i,  new.val )
            }
          }

          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(optimx::optimr(par = initG ,
                                          fn = frail_adtneh_ll_fn,
                                          gr = adtneh_SDtheta,
                                          method = method_opt,
                                          hessian = TRUE,
                                          lower = theta_lower,
                                          upper = theta_upper,
                                          control = list(maxit = maxit_opt,
                                                         trace = trace,
                                                         REPORT = 500)), TRUE)

        } else if (NCD == "iter") {
          optimized_theta <- try(optimx::optimr(par = theta,
                                                fn = frail_adtneh_ll_fn,
                                                gr = adtneh_SDtheta,
                                                method = method_opt,
                                                hessian = TRUE,
                                                lower = theta_lower,
                                                upper = theta_upper,
                                                control = list(maxit = maxit_opt,
                                                               trace = trace,
                                                               REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }

          j = 0
          mydiff <- matrix(data = 1,
                           nrow = 10000,
                           ncol = 1)
          loglik_val <- matrix(data = 0,
                               nrow = 10000,
                               ncol = 1)
          theta_val <- matrix(data = 0,
                              nrow = 10000,
                              ncol = length(theta))
          while (abs(mydiff[j + 1, ]) > iter_eps && (j = j + 1) < 10000) {
            print(j)
            cat("cycle =", j, "\n")

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })


              new.valpar <- try(optimx::optimr(par = init.cd[i],
                                               fn = tempf,
                                               method = method_opt,
                                               hessian = TRUE,
                                               lower = theta_lower[i],
                                               upper = theta_upper[i],
                                               control = list(
                                                 maxit = maxit_opt, trace = trace,
                                                 REPORT = 500)), TRUE)

              new.val <- try(new.valpar$par, TRUE)

              cat("new initial value of parameter number",i,
                  "is equal to:",
                  new.val, "\n")

              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- (theta_lower[i] + theta_upper[i])/2
              }



              init.cd <- replace(init.cd, i,  new.val )

            }
            theta_val[j, ] <-  theta
            theta_val[j + 1, ] <- try(init.cd, TRUE)
            loglik_val[j + 1,] <- try(c(new.valpar$value), TRUE)
            mydiff[j + 1, ] <- try(c(loglik_val[j + 1, ] -
                                 loglik_val[j, ]), TRUE)
            cat("difference between loglikelihood at iter = ",
                j + 1,
                "equal",
                mydiff[j + 1, ],
                ". The j+1 th logliklihood equal",
                loglik_val[j + 1, ],
                ".\n")

            if (abs(loglik_val[(j + 1), ]) == Inf |
                abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                loglik_val[(j + 1), ] > 0) {
              loglik_val[(j + 1), ] = 10000
              mydiff[(j + 1), ]     = 10000
            } else if (abs(loglik_val[(j + 1), ]) == Inf |
                       abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                       loglik_val[(j + 1), ] < 0) {
              loglik_val[(j + 1), ] = -10000
              mydiff[(j + 1), ]     = -10000
            }

            if (j >= 2) {
            par(mfrow = c(1, 2))
            plot(2:(j + 1),
                 loglik_val[2:(j + 1),],
                 type = "l",
                 col = 2,
                 ylab = "loglik",
                 xlab = "iter")
            graphics::grid()
            plot(2:(j + 1),
                 abs(mydiff[2:(j + 1),]),
                 type = "l",
                 col = "green",
                 ylab = "loglik_abs_diff",
                 xlab = "iter")
            graphics::grid()
            par(mfrow = c(1, 1))
            }
          }


          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(optimx::optimr(par = initG ,
                                          fn = frail_adtneh_ll_fn,
                                          gr = adtneh_SDtheta,
                                          method = method_opt,
                                          hessian = TRUE,
                                          lower = theta_lower,
                                          upper = theta_upper,
                                          control = list(maxit = maxit_opt,
                                                         trace = trace,
                                                         REPORT = 500)), TRUE)

        }#end loop of iter



      }else {
        NCD <- ncoor_des

        if (is.null(NCD)) {
          optimized <- optimr(par = theta ,
                                      fn = frail_adtneh_ll_fn,
                                      method = method_opt,
                                      hessian = TRUE,
                                      lower = theta_lower,
                                      upper = theta_upper,
                                      control = list(maxit = maxit_opt,
                                                     trace = trace,
                                                     REPORT = 500))

        } else if (is.numeric(NCD)) {
          optimized_theta <- try(optimx::optimr(par = theta,
                                                fn = frail_adtneh_ll_fn,
                                                method = method_opt,
                                                hessian = TRUE,
                                                lower = theta_lower,
                                                upper = theta_upper,
                                                control = list(maxit = maxit_opt,
                                                               trace = trace,
                                                               REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }


          for (j in 1:NCD) {
            print(j)
            cat("cycle =", j, "\n")

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })

              new.val <- try(optimx::optimr(par = init.cd[i],
                                        fn = tempf,
                                        method = method_opt,
                                        hessian = TRUE,
                                        lower = theta_lower[i],
                                        upper = theta_upper[i],
                                        control = list(
                                          maxit = maxit_opt, trace = trace,
                                          REPORT = 500))$par, TRUE)
              cat("new initial value of parameter number",i,"is equal to:",new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- (theta_lower[i] + theta_upper[i])/2
              }
              init.cd <- replace(init.cd, i,  new.val )
            }
          }
          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(optimx::optimr(par = initG ,
                                          fn = frail_adtneh_ll_fn,
                                          method = method_opt,
                                          hessian = TRUE,
                                          lower = theta_lower,
                                          upper = theta_upper,
                                          control = list(maxit = maxit_opt,
                                                         trace = trace,
                                                         REPORT = 500)), TRUE)

        } else if (NCD == "iter") {

          optimized_theta <- try(optimx::optimr(par = theta,
                                                fn = frail_adtneh_ll_fn,
                                                method = method_opt,
                                                hessian = TRUE,
                                                lower = theta_lower,
                                                upper = theta_upper,
                                                control = list(maxit = maxit_opt,
                                                               trace = trace,
                                                               REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }

          # for (j in 1:NCD) {
          j = 0
          mydiff <- matrix(data = 1,
                           nrow = 10000,
                           ncol = 1)
          loglik_val <- matrix(data = 0,
                               nrow = 10000,
                               ncol = 1)
          theta_val <- matrix(data = 0,
                              nrow = 10000,
                              ncol = length(theta))
          while (abs(mydiff[j + 1, ]) > iter_eps && (j = j + 1) < 10000) {
            print(j)
            cat("cycle =", j, "\n")

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })


              new.valpar <- try(optimx::optimr(par = init.cd[i],
                                               fn = tempf,
                                               method = method_opt,
                                               hessian = TRUE,
                                               lower = theta_lower[i],
                                               upper = theta_upper[i],
                                               control = list(
                                                 maxit = maxit_opt, trace = trace,
                                                 REPORT = 500)), TRUE)

              new.val <- try(new.valpar$par, TRUE)

              cat("new initial value of parameter number",i,"is equal to:",new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- (theta_lower[i] + theta_upper[i])/2
              }



              init.cd <- replace(init.cd, i,  new.val )

            }
            theta_val[j, ] <-  theta
            theta_val[j + 1, ] <- try(init.cd, TRUE)
            loglik_val[j + 1,] <- try(c(new.valpar$value), TRUE)
            mydiff[j + 1, ] <- try(c(loglik_val[j + 1, ] -
                                       loglik_val[j, ]), TRUE)
            cat("difference between loglikelihood at iter = ",
                j + 1,
                "equal",
                mydiff[j + 1, ],
                ". The j+1 th logliklihood equal",
                loglik_val[j + 1, ],
                ".\n")

            if (abs(loglik_val[(j + 1), ]) == Inf |
                abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                loglik_val[(j + 1), ] > 0) {
              loglik_val[(j + 1), ] = 10000
              mydiff[(j + 1), ]     = 10000
            } else if (abs(loglik_val[(j + 1), ]) == Inf |
                       abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                       loglik_val[(j + 1), ] < 0) {
              loglik_val[(j + 1), ] = -10000
              mydiff[(j + 1), ]     = -10000
            }

            if (j >= 2) {
            par(mfrow = c(1, 2))
            plot(2:(j + 1),
                 loglik_val[2:(j + 1),],
                 type = "l",
                 col = 2,
                 ylab = "loglik",
                 xlab = "iter")
            graphics::grid()
            plot(2:(j + 1),
                 abs(mydiff[2:(j + 1),]),
                 type = "l",
                 col = "green",
                 ylab = "loglik_abs_diff",
                 xlab = "iter")
            graphics::grid()
            par(mfrow = c(1, 1))
            }
          }
          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(optimx::optimr(par = initG ,
                                          fn = frail_adtneh_ll_fn,
                                          method = method_opt,
                                          hessian = TRUE,
                                          lower = theta_lower,
                                          upper = theta_upper,
                                          control = list(maxit = maxit_opt,
                                                         trace = trace,
                                                         REPORT = 500)), TRUE)
        }
      }
      ##other methods in optimr without lower and upper constraints
    } else {

      if (gradient) {
        NCD <- ncoor_des
        if (is.null(NCD)) {
        optimized <- optimr(par = theta,
                                    fn = frail_adtneh_ll_fn,
                                    method = method_opt,
                                    gr = adtneh_SDtheta,
                                    hessian = TRUE,
                                    control = list(maxit = maxit_opt,
                                                   trace = trace,
                                                   REPORT = 500))
        } else if (is.numeric(NCD)) {
          optimized_theta <- try(optimx::optimr(par = theta,
                                                fn = frail_adtneh_ll_fn,
                                                gr = adtneh_SDtheta,
                                                method = method_opt,
                                                hessian = TRUE,
                                                control = list(maxit = maxit_opt,
                                                               trace = trace,
                                                               REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }

          for (j in 1:NCD) {
            print(j)
            cat("cycle =", j, "\n")
            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })

              new.val <- try(optimx::optimr(par = init.cd[i],
                                        fn = tempf,
                                        method = method_opt,
                                        hessian = TRUE,
                                        control = list(
                                          maxit = maxit_opt, trace = trace,
                                          REPORT = 500))$par, TRUE)
              cat("new initial value of parameter number", i,
                  "is equal to:", new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- init.cd[i] + 1
              }
              init.cd <- replace(init.cd, i,  new.val )
            }
          }

          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(optimx::optimr(par = initG ,
                                          fn = frail_adtneh_ll_fn,
                                          gr = adtneh_SDtheta,
                                          method = method_opt,
                                          hessian = TRUE,
                                          control = list(maxit = maxit_opt,
                                                         trace = trace,
                                                         REPORT = 500)), TRUE)
        }else if (NCD == "iter") {

          optimized_theta <- try(optimx::optimr(par = theta,
                                                fn = frail_adtneh_ll_fn,
                                                gr = adtneh_SDtheta,
                                                method = method_opt,
                                                hessian = TRUE,
                                                control = list(maxit = maxit_opt,
                                                               trace = trace,
                                                               REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }


          j = 0
          mydiff <- matrix(data = 1,
                           nrow = 10000,
                           ncol = 1)
          loglik_val <- matrix(data = 0,
                               nrow = 10000,
                               ncol = 1)
          theta_val <- matrix(data = 0,
                              nrow = 10000,
                              ncol = length(theta))
          while (abs(mydiff[j + 1, ]) > iter_eps && (j = j + 1) < 10000) {
            print(j)
            cat("cycle =", j, "\n")
            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })


              new.valpar <- try(optimx::optimr(par = init.cd[i],
                                               fn = tempf,
                                               method = method_opt,
                                               hessian = TRUE,
                                               control = list(
                                                 maxit = maxit_opt, trace = trace,
                                                 REPORT = 500)), TRUE)

              new.val <- try(new.valpar$par, TRUE)

              cat("new initial value of parameter number",i,"is equal to:",new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- init.cd[i] + 1
              }
              init.cd <- replace(init.cd, i,  new.val )
            }
            theta_val[j, ] <-  theta
            theta_val[j + 1, ] <- try(init.cd, TRUE)
            loglik_val[j + 1,] <- try(c(new.valpar$value), TRUE)
            mydiff[j + 1, ] <- try(c(loglik_val[j + 1, ] -
                                       loglik_val[j, ]), TRUE)
            cat("difference between loglikelihood at iter = ",
                j + 1,
                "equal",
                mydiff[j + 1, ],
                ". The j+1 th logliklihood equal",
                loglik_val[j + 1, ],
                ".\n")

            if (abs(loglik_val[(j + 1), ]) == Inf |
                abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                loglik_val[(j + 1), ] > 0) {
              loglik_val[(j + 1), ] = 10000
              mydiff[(j + 1), ]     = 10000
            } else if (abs(loglik_val[(j + 1), ]) == Inf |
                       abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                       loglik_val[(j + 1), ] < 0) {
              loglik_val[(j + 1), ] = -10000
              mydiff[(j + 1), ]     = -10000
            }

            if (j >= 2) {
            par(mfrow = c(1, 2))
            plot(2:(j + 1),
                 loglik_val[2:(j + 1),],
                 type = "l",
                 col = 2,
                 ylab = "loglik",
                 xlab = "iter")
            graphics::grid()
            plot(2:(j + 1),
                 abs(mydiff[2:(j + 1),]),
                 type = "l",
                 col = "green",
                 ylab = "loglik_abs_diff",
                 xlab = "iter")
            graphics::grid()
            par(mfrow = c(1, 1))
            }
          }
          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(optimx::optimr(par = initG ,
                                          fn = frail_adtneh_ll_fn,
                                          gr = adtneh_SDtheta,
                                          method = method_opt,
                                          hessian = TRUE,
                                          control = list(maxit = maxit_opt,
                                                         trace = trace,
                                                         REPORT = 500)), TRUE)
        }
      }else {

        NCD <- ncoor_des

        if (is.null(NCD)) {
          optimized <- optimr(par = theta ,
                                      fn = frail_adtneh_ll_fn,
                                      method = method_opt,
                                      hessian = TRUE,
                                      control = list(maxit = maxit_opt,
                                                     trace = trace,
                                                     REPORT = 500))

        } else if (is.numeric(NCD)) {
          optimized_theta <- try(optimx::optimr(par = theta,
                                                fn = frail_adtneh_ll_fn,
                                                method = method_opt,
                                                hessian = TRUE,
                                                control = list(maxit = maxit_opt,
                                                               trace = trace,
                                                               REPORT = 500))$par, TRUE)

          if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
            init.cd <- theta
          }  else {
            init.cd <- optimized_theta
          }

          for (j in 1:NCD) {
            print(j)
            cat("cycle =", j, "\n")

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })
              new.val <- try(optimx::optimr(par = init.cd[i],
                                        fn = tempf,
                                        method = method_opt,
                                        hessian = TRUE,
                                        control = list(
                                          maxit = maxit_opt, trace = trace,
                                          REPORT = 500))$par, TRUE)
              cat("new initial value of parameter number",
                  i,"is equal to:", new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- init.cd[i] + 1
              }
              init.cd <- replace(init.cd, i,  new.val )
            }
          }

          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(optimx::optimr(par = initG ,
                                          fn = frail_adtneh_ll_fn,
                                          method = method_opt,
                                          hessian = TRUE,
                                          control = list(maxit = maxit_opt,
                                                         trace = trace,
                                                         REPORT = 500)), TRUE)

        }else if (NCD == "iter") {
          {
            optimized_theta <- try(optimx::optimr(par = theta,
                                                  fn = frail_adtneh_ll_fn,
                                                  method = method_opt,
                                                  hessian = TRUE,
                                                  control = list(maxit = maxit_opt,
                                                                 trace = trace,
                                                                 REPORT = 500))$par, TRUE)

            if (any(is.na(optimized_theta) || (inherits(optimized_theta, "try-error")))) {
              init.cd <- theta
            }  else {
              init.cd <- optimized_theta
            }

            j = 0
            mydiff <- matrix(data = 1,
                             nrow = 10000,
                             ncol = 1)
            loglik_val <- matrix(data = 0,
                                 nrow = 10000,
                                 ncol = 1)
            theta_val <- matrix(data = 0,
                                nrow = 10000,
                                ncol = length(theta))
            while (abs(mydiff[j + 1, ]) > iter_eps && (j = j + 1) < 10000) {
              print(j)
              cat("cycle =", j, "\n")
              for (i in 1:length(init.cd)) {
                tempf <- Vectorize(function(par){
                  val <- replace(init.cd, i, par)
                  return(frail_adtneh_ll_fn(val))
                })


                new.valpar <- try(optimx::optimr(par = init.cd[i],
                                                 fn = tempf,
                                                 method = method_opt,
                                                 hessian = TRUE,
                                                 control = list(
                                                   maxit = maxit_opt, trace = trace,
                                                   REPORT = 500)), TRUE)

                new.val <- try(new.valpar$par, TRUE)

                cat("new initial value of parameter number",i,"is equal to:",new.val)
                cat("\n")
                if (anyNA(new.val) | inherits(new.val, "try-error")) {
                  new.val <- init.cd[i] + 1
                }
                init.cd <- replace(init.cd, i,  new.val )
              }
              theta_val[j, ] <-  theta
              theta_val[j + 1, ] <- try(init.cd, TRUE)
              loglik_val[j + 1,] <- try(c(new.valpar$value), TRUE)
              mydiff[j + 1, ] <- try(c(loglik_val[j + 1, ] -
                                         loglik_val[j, ]), TRUE)
              cat("difference between loglikelihood at iter = ",
                  j + 1,
                  "equal",
                  mydiff[j + 1, ],
                  ". The j+1 th logliklihood equal",
                  loglik_val[j + 1, ],
                  ".\n")

              if (abs(loglik_val[(j + 1), ]) == Inf |
                  abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                  loglik_val[(j + 1), ] > 0) {
                loglik_val[(j + 1), ] = 10000
                mydiff[(j + 1), ]     = 10000
              } else if (abs(loglik_val[(j + 1), ]) == Inf |
                         abs(loglik_val[(j + 1), ]) == .Machine$double.xmax &
                         loglik_val[(j + 1), ] < 0) {
                loglik_val[(j + 1), ] = -10000
                mydiff[(j + 1), ]     = -10000
              }


              if (j >= 2) {
              par(mfrow = c(1, 2))
              plot(2:(j + 1),
                   loglik_val[2:(j + 1),],
                   type = "l",
                   col = 2,
                   ylab = "loglik",
                   xlab = "iter")
              graphics::grid()
              plot(2:(j + 1),
                   abs(mydiff[2:(j + 1),]),
                   type = "l",
                   col = "green",
                   ylab = "loglik_abs_diff",
                   xlab = "iter")
              graphics::grid()
              par(mfrow = c(1, 1))
              }
            }
            if (any(is.na(init.cd))) {
              initG <- theta
            }  else {
              initG <- init.cd
            }

            optimized <- try(optimx::optimr(par = initG ,
                                            fn = frail_adtneh_ll_fn,
                                            method = method_opt,
                                            hessian = TRUE,
                                            control = list(maxit = maxit_opt,
                                                           trace = trace,
                                                           REPORT = 500)), TRUE)
          }
        }
      }
      ##end other methods optimr
    }
  } else if (optim_func == "bbmle") {
    #begin bbmle

    if (method_opt == "L-BFGS-B" |
        method_opt == "Rvmmin" |
        method_opt == "Rcgmin" |
        method_opt == "nlminb" |
        method_opt == "bobyqa" ) {
      if (gradient) {

        NCD <- ncoor_des

        if (is.null(NCD)) {
          optimized <- stats::optim(par = theta,
                                    fn = frail_adtneh_ll_fn,
                                    gr = adtneh_SDtheta,
                                    method = method_opt,#"L-BFGS-B",
                                    hessian = TRUE,
                                    lower = theta_lower,
                                    upper = theta_upper,
                                    control = list(maxit = maxit_opt,
                                                   trace = trace,
                                                   REPORT = 500))
        } else {

          init.cd <- theta
          for (j in 1:NCD) {
            print(j)
            cat("cycle =", j, "\n")

            for (i in 1:length(init.cd)) {
              tempf <- Vectorize(function(par){
                val <- replace(init.cd, i, par)
                return(frail_adtneh_ll_fn(val))
              })

              new.val <- try(stats::optim(par = init.cd[i],
                                          fn = tempf,
                                          method = method_opt,
                                          hessian = TRUE,
                                          lower = theta_lower[i],
                                          upper = theta_upper[i],
                                          control = list(
                                            maxit = maxit_opt, trace = trace,
                                            REPORT = 500))$par, TRUE)
              cat("new initial value of parameter number",i,"is equal to:",new.val)
              cat("\n")
              if (anyNA(new.val) | inherits(new.val, "try-error")) {
                new.val <- (theta_lower[i] + theta_upper[i])/2
              }
              init.cd <- replace(init.cd, i,  new.val )
            }
          }

          if (any(is.na(init.cd))) {
            initG <- theta
          }  else {
            initG <- init.cd
          }

          optimized <- try(stats::optim(par = initG ,
                                        fn = frail_adtneh_ll_fn,
                                        gr = adtneh_SDtheta,
                                        method = method_opt,
                                        hessian = TRUE,
                                        lower = theta_lower,
                                        upper = theta_upper,
                                        control = list(maxit = maxit_opt,
                                                       trace = trace,
                                                       REPORT = 500)), TRUE)



        }



      }else {
        NCD <- ncoor_des

        if (is.null(NCD)) {
          ##
          par_adtneh2 <- genpar_frailtytneh(theta, z_tau, z_alpha)

          if (n_z_tau > 0 & n_z_alpha > 0) {
            alpha0 <- par_adtneh2["alpha0"]
            alpha_k <- par_adtneh2[
              c(which(stringr::str_detect(names(par_adtneh2),"alpha_k")))]
            beta <- par_adtneh2["beta"]
            tau0 <- par_adtneh2["tau0"]
            tau_z <- par_adtneh2[
              c(which(stringr::str_detect(names(par_adtneh2),"tau_z")))]
            mu <- par_adtneh2["mu"]
            psi <- par_adtneh2["psi"]




              start <- c(alpha0 = as.numeric(alpha0),
                         alpha_k = as.numeric(alpha_k),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         tau_z = as.numeric(tau_z),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))

            names(start) <- names(theta2)



          }else if (n_z_tau > 0 & n_z_alpha == 0) {
            alpha0 <- par_adtneh2["alpha0"]
            beta <- par_adtneh2["beta"]
            tau0 <- par_adtneh2["tau0"]
            tau_z <- par_adtneh2[
              c(which(stringr::str_detect(names(par_adtneh2),"tau_z")))]
            mu <- par_adtneh2["mu"]
            psi <- par_adtneh2["psi"]

              start <- c(alpha0 = as.numeric(alpha0),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         tau_z = as.numeric(tau_z),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))


            names(start) <- names(theta2)

          }else if (n_z_tau == 0 & n_z_alpha > 0) {

            alpha0 <- par_adtneh2["alpha0"]
            alpha_k <- par_adtneh2[
              c(which(stringr::str_detect(names(par_adtneh2),"alpha_k")))]
            beta <- par_adtneh2["beta"]
            tau0 <- par_adtneh2["tau0"]
            mu <- par_adtneh2["mu"]
            psi <- par_adtneh2["psi"]
            start <- c(alpha0 = as.numeric(alpha0),
                         alpha_k = as.numeric(alpha_k),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))


            names(start) <- names(theta2)

          }else if (n_z_tau == 0 & n_z_alpha == 0) {

            alpha0 <- par_adtneh2["alpha0"]
            beta <- par_adtneh2["beta"]
            tau0 <- par_adtneh2["tau0"]
            mu <- par_adtneh2["mu"]
            psi <- par_adtneh2["psi"]

              start <- c(alpha0 = as.numeric(alpha0),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))


            names(start) <- names(theta2)

          }


          add.arguments <- function(f, params) {
            # adds n arguments to a function f; returns that new function
            t <- paste("arg <- alist(",
                       paste(sapply(1:length(params),
                                    function(i)
                                      paste(names(params)[i], "=", sep = "")),
                             collapse = ","),
                       ")", sep = "")
            formals(f) <- eval(parse(text = t))
            f
          }

          frail_adtneh_ll_fn2noalpha2 <- add.arguments(frail_adtneh_ll_fn3, start)
          bbmle::parnames(frail_adtneh_ll_fn2noalpha2) <- names(theta2)


          start2 <- paste("list(",
                          paste(sapply(1:length(start),
                                       function(i)
                                         paste(names(start)[i], "=",(start)[i], sep = "")),
                                collapse = ","),
                          ")", sep = "")
          start3 <- eval(parse(text = start2))

          theta_lower2 <- paste("list(",
                                paste(sapply(1:length(start),
                                             function(i)
                                               paste(names(start)[i], "=",
                                                     (theta_lower)[i], sep = "")),
                                      collapse = ","),
                                ")", sep = "")

          theta_upper2 <- paste("list(",
                                paste(sapply(1:length(start),
                                             function(i)
                                               paste(names(start)[i], "=",
                                                     (theta_upper)[i], sep = "")),
                                      collapse = ","),
                                ")", sep = "")

          theta_lower3 <- eval(parse(text = theta_lower2))
          theta_upper3 <- eval(parse(text = theta_upper2))

          optimized <- bbmle::mle2(
            start = start3,
            minuslogl = frail_adtneh_ll_fn2noalpha2,
            fixed = fixed,
            optimizer = optimizer,
            method = method_opt,
            lower = unlist(theta_lower3),
            upper = unlist(theta_upper3),
            control = list(maxit = maxit_opt,
                           trace = trace))

          ##




        }
      }




    }
    else
    {if (gradient) {

      NCD <- ncoor_des
      if (is.null(NCD)) {
        optimized <- stats::optim(par = theta,
                                  fn = frail_adtneh_ll_fn,
                                  gr = adtneh_SDtheta,
                                  method = method_opt,
                                  control = list(pgtol = 1e-15,
                                                 maxit = maxit_opt,
                                                 trace = trace,
                                                 REPORT = 500))
      } else{
        init.cd <- theta
        for (j in 1:NCD) {
          print(j)
          cat("cycle =", j, "\n")
          for (i in 1:length(init.cd)) {
            tempf <- Vectorize(function(par){
              val <- replace(init.cd, i, par)
              return(frail_adtneh_ll_fn(val))
            })

            new.val <- try(stats::optim(par = init.cd[i],
                                        fn = tempf,
                                        method = method_opt,
                                        control = list(pgtol = 1e-15,
                                                       maxit = maxit_opt,
                                                       trace = trace,
                                                       REPORT = 500))$par, TRUE)
            cat("new initial value of parameter number",i,"is equal to:",new.val)
            cat("\n")
            if (anyNA(new.val) | inherits(new.val, "try-error")) {
              new.val <- (theta_lower[i] + theta_upper[i])/2
            }
            init.cd <- replace(init.cd, i,  new.val )
          }
        }

        if (any(is.na(init.cd))) {
          initG <- theta
        }  else {
          initG <- init.cd
        }

        optimized <- try(stats::optim(par = initG ,
                                      fn = frail_adtneh_ll_fn,
                                      gr = adtneh_SDtheta,
                                      method = method_opt,
                                      control = list(pgtol = 1e-15,
                                                     maxit = maxit_opt,
                                                     trace = trace,
                                                     REPORT = 500)), TRUE)




      }
    }
      else{

        if (method_opt == "all.methods") {

          NCD <- ncoor_des

          if (is.null(NCD)) {
            ##
            par_adtneh2 <- genpar_frailtytneh(theta, z_tau, z_alpha)

            if (n_z_tau > 0 & n_z_alpha > 0) {
              alpha0 <- par_adtneh2["alpha0"]
              alpha_k <- par_adtneh2[
                c(which(stringr::str_detect(names(par_adtneh2),"alpha_k")))]
              beta <- par_adtneh2["beta"]
              tau0 <- par_adtneh2["tau0"]
              tau_z <- par_adtneh2[
                c(which(stringr::str_detect(names(par_adtneh2),"tau_z")))]
              mu <- par_adtneh2["mu"]
              psi <- par_adtneh2["psi"]




              start <- c(alpha0 = as.numeric(alpha0),
                         alpha_k = as.numeric(alpha_k),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         tau_z = as.numeric(tau_z),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))

              names(start) <- names(theta2)



            }else if (n_z_tau > 0 & n_z_alpha == 0) {
              alpha0 <- par_adtneh2["alpha0"]
              beta <- par_adtneh2["beta"]
              tau0 <- par_adtneh2["tau0"]
              tau_z <- par_adtneh2[
                c(which(stringr::str_detect(names(par_adtneh2),"tau_z")))]
              mu <- par_adtneh2["mu"]
              psi <- par_adtneh2["psi"]

              start <- c(alpha0 = as.numeric(alpha0),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         tau_z = as.numeric(tau_z),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))


              names(start) <- names(theta2)

            }else if (n_z_tau == 0 & n_z_alpha > 0) {

              alpha0 <- par_adtneh2["alpha0"]
              alpha_k <- par_adtneh2[
                c(which(stringr::str_detect(names(par_adtneh2),"alpha_k")))]
              beta <- par_adtneh2["beta"]
              tau0 <- par_adtneh2["tau0"]
              mu <- par_adtneh2["mu"]
              psi <- par_adtneh2["psi"]
              start <- c(alpha0 = as.numeric(alpha0),
                         alpha_k = as.numeric(alpha_k),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))


              names(start) <- names(theta2)

            }else if (n_z_tau == 0 & n_z_alpha == 0) {

              alpha0 <- par_adtneh2["alpha0"]
              beta <- par_adtneh2["beta"]
              tau0 <- par_adtneh2["tau0"]
              mu <- par_adtneh2["mu"]
              psi <- par_adtneh2["psi"]

              start <- c(alpha0 = as.numeric(alpha0),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))


              names(start) <- names(theta2)

            }


            add.arguments <- function(f, params) {
              # adds n arguments to a function f; returns that new function
              t <- paste("arg <- alist(",
                         paste(sapply(1:length(params),
                                      function(i)
                                        paste(names(params)[i], "=", sep = "")),
                               collapse = ","),
                         ")", sep = "")
              formals(f) <- eval(parse(text = t))
              f
            }

            frail_adtneh_ll_fn2noalpha2 <- add.arguments(frail_adtneh_ll_fn3, start)
            bbmle::parnames(frail_adtneh_ll_fn2noalpha2) <- names(theta2)


            # bbmle::parnames(adtneh_ll_fn2noalpha) <- c("alpha0",colnames(z_alpha),"beta", colnames(z_tau))

            # start <- setNames(mypar,
            # c("alpha0",
            # colnames(z_alpha), "beta","tau0", colnames(z_tau)))
            start2 <- paste("list(",
                            paste(sapply(1:length(start),
                                         function(i)
                                           paste(names(start)[i], "=",(start)[i], sep = "")),
                                  collapse = ","),
                            ")", sep = "")
            start3 <- eval(parse(text = start2))

            theta_lower2 <- paste("list(",
                                  paste(sapply(1:length(start),
                                               function(i)
                                                 paste(names(start)[i], "=",
                                                       (theta_lower)[i], sep = "")),
                                        collapse = ","),
                                  ")", sep = "")

            theta_upper2 <- paste("list(",
                                  paste(sapply(1:length(start),
                                               function(i)
                                                 paste(names(start)[i], "=",
                                                       (theta_upper)[i], sep = "")),
                                        collapse = ","),
                                  ")", sep = "")

            theta_lower3 <- eval(parse(text = theta_lower2))
            theta_upper3 <- eval(parse(text = theta_upper2))




            optimized2 <- optimx::optimx(
              par = unlist(start3),
              fn = frail_adtneh_ll_fn,
              lower = unlist(theta_lower3),
              upper = unlist(theta_upper3),
              control = list(all.methods = TRUE,
                             maximize = FALSE,
                             trace = trace,
                             save.failures = TRUE))

            optimized <- bbmle::mle2(
              start = start3,
              minuslogl = frail_adtneh_ll_fn2noalpha2,
              fixed = fixed,
              lower = unlist(theta_lower3),
              upper = unlist(theta_upper3),
              control = list(all.methods = TRUE,
                             maximize = FALSE,
                             trace = trace,
                             save.failures = TRUE))

            ##




          } else {
            init.cd <- theta
            for (j in 1:NCD) {
              print(j)
              cat("cycle =", j, "\n")

              for (i in 1:length(init.cd)) {
                tempf <- Vectorize(function(par){
                  val <- replace(init.cd, i, par)
                  return(adtneh_ll_fn(val))
                })

                new.val <- try(stats::optim(par = init.cd[i],
                                            fn = tempf,
                                            method = method_opt,
                                            hessian = TRUE,
                                            lower = theta_lower[i],
                                            upper = theta_upper[i],
                                            control = list(
                                              maxit = maxit_opt, trace = trace,
                                              REPORT = 500))$par, TRUE)
                cat("new initial value of parameter number",i,"is equal to:",new.val)
                cat("\n")
                if (anyNA(new.val) | inherits(new.val, "try-error")) {
                  new.val <- (theta_lower[i] + theta_upper[i])/2
                }

                init.cd <- replace(init.cd, i,  new.val )
              }
            }

            if (any(is.na(init.cd))) {
              initG <- theta
            }  else {
              initG <- init.cd
            }

            optimized <- try(stats::optim(par = initG ,
                                          fn = adtneh_ll_fn,
                                          method = method_opt,
                                          hessian = TRUE,
                                          lower = theta_lower,
                                          upper = theta_upper,
                                          control = list(maxit = maxit_opt,
                                                         trace = trace,
                                                         REPORT = 500)), TRUE)

          }

        }else{
          if (gradient) {


            NCD <- ncoor_des
            if (is.null(NCD)) {
              optimized <- stats::optim(par = theta,
                                        fn = adtneh_ll_fn,
                                        gr = adtneh_SDtheta,
                                        method = method_opt,
                                        control = list(pgtol = 1e-15,
                                                       maxit = maxit_opt,
                                                       trace = trace,
                                                       REPORT = 500))
            } else{
              init.cd <- theta
              for (j in 1:NCD) {
                print(j)
                cat("cycle =", j, "\n")
                for (i in 1:length(init.cd)) {
                  tempf <- Vectorize(function(par){
                    val <- replace(init.cd, i, par)
                    return(adtneh_ll_fn(val))
                  })

                  new.val <- try(stats::optim(par = init.cd[i],
                                              fn = tempf,
                                              method = method_opt,
                                              control = list(pgtol = 1e-15,
                                                             maxit = maxit_opt,
                                                             trace = trace,
                                                             REPORT = 500))$par, TRUE)
                  cat("new initial value of parameter number",i,"is equal to:",new.val)
                  cat("\n")
                  if (anyNA(new.val) | inherits(new.val, "try-error")) {
                    new.val <- (theta_lower[i] + theta_upper[i])/2
                  }
                  init.cd <- replace(init.cd, i,  new.val )
                }
              }

              if (any(is.na(init.cd))) {
                initG <- theta
              }  else {
                initG <- init.cd
              }

              optimized <- try(stats::optim(par = initG ,
                                            fn = adtneh_ll_fn,
                                            gr = adtneh_SDtheta,
                                            method = method_opt,
                                            control = list(pgtol = 1e-15,
                                                           maxit = maxit_opt,
                                                           trace = trace,
                                                           REPORT = 500)), TRUE)




            }

          }else{

            ##
            par_adtneh2 <- genpar_frailtytneh(theta, z_tau, z_alpha)

            if (n_z_tau > 0 & n_z_alpha > 0) {
              alpha0 <- par_adtneh2["alpha0"]
              alpha_k <- par_adtneh2[
                c(which(stringr::str_detect(names(par_adtneh2),"alpha_k")))]
              beta <- par_adtneh2["beta"]
              tau0 <- par_adtneh2["tau0"]
              tau_z <- par_adtneh2[
                c(which(stringr::str_detect(names(par_adtneh2),"tau_z")))]
              mu <- par_adtneh2["mu"]
              psi <- par_adtneh2["psi"]




              start <- c(alpha0 = as.numeric(alpha0),
                         alpha_k = as.numeric(alpha_k),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         tau_z = as.numeric(tau_z),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))

              names(start) <- names(theta2)



            }else if (n_z_tau > 0 & n_z_alpha == 0) {
              alpha0 <- par_adtneh2["alpha0"]
              beta <- par_adtneh2["beta"]
              tau0 <- par_adtneh2["tau0"]
              tau_z <- par_adtneh2[
                c(which(stringr::str_detect(names(par_adtneh2),"tau_z")))]
              mu <- par_adtneh2["mu"]
              psi <- par_adtneh2["psi"]

              start <- c(alpha0 = as.numeric(alpha0),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         tau_z = as.numeric(tau_z),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))


              names(start) <- names(theta2)

            }else if (n_z_tau == 0 & n_z_alpha > 0) {

              alpha0 <- par_adtneh2["alpha0"]
              alpha_k <- par_adtneh2[
                c(which(stringr::str_detect(names(par_adtneh2),"alpha_k")))]
              beta <- par_adtneh2["beta"]
              tau0 <- par_adtneh2["tau0"]
              mu <- par_adtneh2["mu"]
              psi <- par_adtneh2["psi"]
              start <- c(alpha0 = as.numeric(alpha0),
                         alpha_k = as.numeric(alpha_k),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))


              names(start) <- names(theta2)

            }else if (n_z_tau == 0 & n_z_alpha == 0) {

              alpha0 <- par_adtneh2["alpha0"]
              beta <- par_adtneh2["beta"]
              tau0 <- par_adtneh2["tau0"]
              mu <- par_adtneh2["mu"]
              psi <- par_adtneh2["psi"]

              start <- c(alpha0 = as.numeric(alpha0),
                         beta = as.numeric(beta),
                         tau0 = as.numeric(tau0),
                         mu = as.numeric(mu),
                         psi = as.numeric(psi))


              names(start) <- names(theta2)

            }


            add.arguments <- function(f, params) {
              # adds n arguments to a function f; returns that new function
              t <- paste("arg <- alist(",
                         paste(sapply(1:length(params),
                                      function(i)
                                        paste(names(params)[i], "=", sep = "")),
                               collapse = ","),
                         ")", sep = "")
              formals(f) <- eval(parse(text = t))
              f
            }

            frail_adtneh_ll_fn2noalpha2 <- add.arguments(frail_adtneh_ll_fn3, start)
            bbmle::parnames(frail_adtneh_ll_fn2noalpha2) <- names(theta2)



            # bbmle::parnames(adtneh_ll_fn2noalpha) <- c("alpha0",colnames(z_alpha),"beta", colnames(z_tau))

            # start <- setNames(mypar,
            # c("alpha0",
            # colnames(z_alpha), "beta","tau0", colnames(z_tau)))
            start2 <- paste("list(",
                            paste(sapply(1:length(start),
                                         function(i)
                                           paste(names(start)[i], "=",(start)[i], sep = "")),
                                  collapse = ","),
                            ")", sep = "")
            start3 <- eval(parse(text = start2))

            theta_lower2 <- paste("list(",
                                  paste(sapply(1:length(start),
                                               function(i)
                                                 paste(names(start)[i], "=",
                                                       (theta_lower)[i], sep = "")),
                                        collapse = ","),
                                  ")", sep = "")

            theta_upper2 <- paste("list(",
                                  paste(sapply(1:length(start),
                                               function(i)
                                                 paste(names(start)[i], "=",
                                                       (theta_upper)[i], sep = "")),
                                        collapse = ","),
                                  ")", sep = "")

            theta_lower3 <- eval(parse(text = theta_lower2))
            theta_upper3 <- eval(parse(text = theta_upper2))

            optimized <- bbmle::mle2(
              start = start3,
              minuslogl = frail_adtneh_ll_fn2noalpha2,
              fixed = fixed,
              optimizer = optimizer,
              method = method_opt,
              control = list(maxit = maxit_opt,
                             trace = trace))

            ##




          }
        }
      }}


   #end bbmle
  }else
  {
    stop("optim_func can only be bbmle, optimr, optim")
  }


  if (inherits(optimized, "try-error")) {
    stop("The function cannot be evaluated using these initial parameters!")
  }

  # if (optim_func == "marqLev") {
  #
  #   par <- try(optimized$b, TRUE)
  #   AIC <- try(2*optimized$fn.value + 2*length(par), TRUE)
  #   loglik <- try(-optimized$fn.value, TRUE)
  #
  #   evaluations <- try(optimized$ni, TRUE)
  #   iterations <- try(evaluations, TRUE)
  #   convergence <- try(optimized$istop, TRUE)
  #   message <- try(optimized$istop, TRUE)
  #   SD <- try(numDeriv::hessian(frail_adtneh_ll_fn, par), TRUE)
  #
  # }else {

  if (optim_func == "bbmle") {


    par <- try(optimized@details$par, TRUE)


    AIC <- try(2* optimized@details$value + 2*length(par), TRUE)
    loglik <- try(-as.numeric(logLik(optimized)) , TRUE)

    evaluations <- try(optimized@details$counts, TRUE)
    iterations <- try(evaluations, TRUE)
    convergence <- try(optimized@details$convergence, TRUE)
    message <- try(optimized@details$message, TRUE)

    varcov_star <- optimized@vcov
    if (any(inherits(optimized@vcov, "try-error"))) {
      varcov_star <- try(solve(optimized@details$hessian), TRUE)
    }
  } else{

    par <- try(optimized$par, TRUE)
    AIC <- try(2*optimized$value + 2*length(par), TRUE)
    loglik <- try(-optimized$value, TRUE)

    evaluations <- try(optimized$counts, TRUE)
    iterations <- try(evaluations, TRUE)
    convergence <- try(optimized$convergence, TRUE)
    message <- try(optimized$message, TRUE)
    SD <- try(numDeriv::hessian(frail_adtneh_ll_fn, par), TRUE)

  }



  if (hessian_varcov) {
    varcov_star <- try(solve(SD), TRUE)
  } else{
    varcov_star <- try(adtneh_vartheta(z_tau,
                                       z_alpha,
                                       time = x,
                                       theta = par,
                                       d,
                                       pophaz), TRUE)
  }

  if (any(inherits(varcov_star, "try-error"))) {
    varcov_star   <- try(solve(optimized$hessian), TRUE)
  }
  std_err_star <- try(sqrt(diag(varcov_star)), TRUE)

  thetaest <- matrix(par, nrow = 1)
  n_z_tau <- ncol(z_tau)
  n_z_tau_ad <- n_z_tau - 1

  if (pophaz.alpha) {
    if (n_z_tau > 0 & n_z_alpha > 0) {
      colnames(thetaest) <- c('alpha0',
                              paste('alpha', 1:n_z_alpha, colnames(z_alpha) ,sep = "_"),
                              'beta',
                              'tau0',
                              paste('tau', 1:n_z_tau, colnames(z_tau), sep = "_"),
                              'mu', 'psi')


    }else if (n_z_tau > 0 & n_z_alpha == 0) {
      colnames(thetaest) <- c('alpha0',
                              'beta',
                              'tau0',
                              paste('tau', 1:n_z_tau, colnames(z_tau), sep = "_"),
                              'mu', 'psi')
    }else if (n_z_tau == 0 & n_z_alpha > 0) {
      colnames(thetaest) <- c('alpha0',
                              paste('alpha', 1:n_z_alpha, colnames(z_alpha) ,sep = "_"),
                              'beta',
                              'tau0',
                              'mu', 'psi')
      }else if (n_z_tau == 0 & n_z_alpha == 0) {

                                  colnames(thetaest) <- c('alpha0',
                                                          'beta',
                                                          'tau0',
                                                          'mu', 'psi')

                              }
  }else
    {
      if (n_z_tau > 0 & n_z_alpha > 0) {
        colnames(thetaest) <- c('alpha0',
                                paste('alpha', 1:n_z_alpha, colnames(z_alpha) ,sep = "_"),
                                'beta',
                                'tau0',
                                paste('tau', 1:n_z_tau, colnames(z_tau), sep = "_"))


      }else if (n_z_tau > 0 & n_z_alpha == 0) {
        colnames(thetaest) <- c('alpha0',
                                'beta',
                                'tau0',
                                paste('tau', 1:n_z_tau, colnames(z_tau), sep = "_"))
      }else if (n_z_tau == 0 & n_z_alpha > 0) {
        colnames(thetaest) <- c('alpha0',
                                paste('alpha', 1:n_z_alpha, colnames(z_alpha) ,sep = "_"),
                                'beta',
                                'tau0')
        }else if (n_z_tau == 0 & n_z_alpha == 0) {

                                    colnames(thetaest) <- c('alpha0',
                                                            'beta',
                                                            'tau0')
                                    }
    }



  id_beta <- which(colnames(thetaest) == 'beta')
  thetaest2 <- thetaest
  thetaest2[-id_beta] <- (thetaest[-id_beta])
  thetaest2[id_beta] <- thetaest[id_beta]

  if (pophaz.alpha) {
    id_pophaz.alpha <- which(colnames(thetaest) %in% c('mu', 'psi'))
    thetaest2[id_pophaz.alpha] <- exp(thetaest[id_pophaz.alpha])
  }
  Dthetaest2 <- thetaest2
  Dthetaest2[-id_beta] <- 1
  Dthetaest2[id_beta] <- 1
  if (pophaz.alpha) {
    Dthetaest2[id_pophaz.alpha] <- exp(thetaest[id_pophaz.alpha])

  }
  varcov <- try(c(Dthetaest2^2)*varcov_star,TRUE)
  std_err <- try((sqrt(diag(varcov))), TRUE)

  if (inherits(std_err, "try-error")) {
    #error print to be implemented
  }else{
    std_err <- try(matrix(std_err, ncol = length(std_err)), TRUE)

    if (pophaz.alpha) {

      if (n_z_tau > 0 & n_z_alpha > 0) {
        colnames(std_err) <- c('alpha0',
                                paste('alpha', 1:n_z_alpha, colnames(z_alpha) ,sep = "_"),
                                'beta',
                                'tau0',
                                paste('tau', 1:n_z_tau, colnames(z_tau), sep = "_"),
                               'mu', 'psi')


      }else if (n_z_tau > 0 & n_z_alpha == 0) {
        colnames(std_err) <- c('alpha0',
                                'beta',
                                'tau0',
                                paste('tau', 1:n_z_tau, colnames(z_tau), sep = "_"),
                               'mu', 'psi')
      }else if (n_z_tau == 0 & n_z_alpha > 0) {
        colnames(std_err) <- c('alpha0',
                                paste('alpha', 1:n_z_alpha, colnames(z_alpha) ,sep = "_"),
                                'beta',
                                'tau0',
                               'mu', 'psi')
        }else
                                  if (n_z_tau == 0 & n_z_alpha == 0) {

                                    colnames(std_err) <- c('alpha0',
                                                            'beta',
                                                            'tau0',
                                                           'mu', 'psi')

                                  }

    }else{

      if (n_z_tau > 0 & n_z_alpha > 0) {
        colnames(std_err) <- c('alpha0',
                                paste('alpha', 1:n_z_alpha, colnames(z_alpha) ,sep = "_"),
                                'beta',
                                'tau0',
                                paste('tau', 1:n_z_tau, colnames(z_tau), sep = "_"))


      }else if (n_z_tau > 0 & n_z_alpha == 0) {
        colnames(std_err) <- c('alpha0',
                                'beta',
                                'tau0',
                                paste('tau', 1:n_z_tau, colnames(z_tau), sep = "_"))
      }else if (n_z_tau == 0 & n_z_alpha > 0) {
        colnames(std_err) <- c('alpha0',
                                paste('alpha', 1:n_z_alpha, colnames(z_alpha) ,sep = "_"),
                                'beta',
                                'tau0')
      }else if (n_z_tau == 0 & n_z_alpha == 0) {

        colnames(std_err) <- c('alpha0',
                                'beta',
                                'tau0')
      }

    }


    ########
    ########

    # colnames(std_err) <- try(c(colnames(thetaest)), TRUE)
    colnames(thetaest) <- try(paste0(colnames(thetaest),"*"),TRUE)
    std_err_star <- matrix(std_err_star, ncol = length(std_err_star))
    colnames(std_err_star) <- try(paste0(colnames(thetaest),"*"), TRUE)
  }

  if (is.null(ncoor_des)) {
    iter_coords <- 0

  }else if (is.numeric(ncoor_des)) {
    iter_coords <- ncoor_des
  }else if (ncoor_des == "iter") {
    iter_coords <- j
  }

  if (pophaz.alpha) {
    thetaest2inf <- thetaest2sup <- thetaest2
    thetaest2inf[id_pophaz.alpha] <- try((thetaest2[id_pophaz.alpha])^exp(1.96 * std_err_star[id_pophaz.alpha]), TRUE)
    thetaest2inf[-id_pophaz.alpha] <- try(thetaest2[-id_pophaz.alpha] - 1.96 * std_err[-id_pophaz.alpha], TRUE)
    thetaest2sup[id_pophaz.alpha] <- try(thetaest2[id_pophaz.alpha]^exp(-1.96 * std_err_star[id_pophaz.alpha]), TRUE)
    thetaest2sup[-id_pophaz.alpha] <- try(thetaest2[-id_pophaz.alpha] + 1.96 * std_err[-id_pophaz.alpha], TRUE)

  }else{
    thetaest2inf <- thetaest2sup <- thetaest2
    thetaest2inf <- thetaest2 - 1.96 * std_err
    thetaest2sup <- thetaest2 + 1.96 * std_err
  }




    if (method_opt == "all.methods") {
      return(
        list(iter_coords = iter_coords,
             coefficients = thetaest,
             estimates = thetaest2,
             estimates_sup = thetaest2sup,
             estimates_inf = thetaest2inf,
             loglik = loglik,
             iterations = iterations,
             evaluations = evaluations,
             convergence = convergence,
             message = message,
             varcov = varcov,
             varcov_star = varcov_star,
             std_err = std_err,
             std_err_star = std_err_star,
             AIC = AIC,
             optimized2 = optimized2
        )
      )
    } else{
      return(
        list(iter_coords = iter_coords,
             coefficients = thetaest,
             estimates = thetaest2,
             estimates_sup = thetaest2sup,
             estimates_inf = thetaest2inf,
             loglik = loglik,
             iterations = iterations,
             evaluations = evaluations,
             convergence = convergence,
             message = message,
             varcov = varcov,
             varcov_star = varcov_star,
             std_err = std_err,
             std_err_star = std_err_star,
             AIC = AIC
        )
      )
    }

}
