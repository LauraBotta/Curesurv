#' @title var_pt_cure_wei function
#'
#' @description Variance of p(t) with delta method. Var(p(t)) = (dp/dtheta)Var(theta)(dp/dtheta)^T
#' where Var(theta) is the variance-covariance matrix of theta.
#'
#' @param object ouput from mixture cure model implemented in curesurv
#'
#' @param z_ucured covariates matrix acting on survival function of uncured
#'
#' @param z_pcured covariates matrix acting on cure proportion
#'
#' @param x time at which the estimates are predicted




var_pt_cure_wei <-
  function(object,
           z_pcured = z_pcured,
           z_ucured = z_ucured,
           x = x) {
    if (!inherits(object, "curesurv"))
      stop("Primary argument much be a curesurv object")

    n_z_pcured <- ncol(z_pcured)
    n_z_ucured <- ncol(z_ucured)

    if (n_z_pcured > 0 & n_z_ucured > 0) {
      dpdtheta_n <-
        dpdtheta_wei(
          z_pcured = z_pcured,
          z_ucured = z_ucured,
          x = x,
          theta = object$coefficients
        )

    } else if (n_z_pcured > 0 & n_z_ucured == 0) {
      dpdtheta_n <-
        dpdtheta_wei(
          z_pcured = z_pcured,
          z_ucured = z_ucured,
          x = x,
          theta = object$coefficients
        )



    } else if (n_z_pcured == 0 & n_z_ucured > 0) {
      dpdtheta_n <-
        dpdtheta_wei(
          z_pcured = z_pcured,
          z_ucured = z_ucured,
          x = x,
          theta = object$coefficients
        )

    } else if (n_z_pcured == 0 & n_z_ucured == 0) {
      dpdtheta_n <-
        dpdtheta_wei(
          z_pcured = z_pcured,
          z_ucured = z_ucured,
          x = x,
          theta = object$coefficients
        )
    }


if(object$pophaz.alpha){
  var_pt <- do.call("cbind",
                    dpdtheta_n) %*%
    object$varcov_star[1:(ncol(object$varcov_star)-1),1:(ncol(object$varcov_star)-1)] %*%
    t(do.call("cbind", dpdtheta_n))
}else{
  var_pt <- do.call("cbind",
                    dpdtheta_n) %*%
    object$varcov_star %*%
    t(do.call("cbind", dpdtheta_n))
}

return(var_pt)
  }

