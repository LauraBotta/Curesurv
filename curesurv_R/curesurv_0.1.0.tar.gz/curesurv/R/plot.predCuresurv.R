#' @title plot.predCuresurv function
#'
#' @description Produces figures of excess hazard, net survival and
#' probability Pi(t) of being cured at a given time t after diagnosis knowing
#' that he/she was alive up to time t.
#'
#' @param x result of the \code{predCuresurv} function
#'
#'
#' @param fun if "haz" or "surv" or "pt_cure", "cumhaz", "logcumhaz", the plot
#' produced is that of excess hazard, or that of net survival, or that of
#' the probability Pi(t) of being cured at a given time t after diagnosis
#' knowing that he/she was alive up to time t is provided, or that of
#' cumulative hazard or that of the logarithm of the cumulative hazard; if
#'  \code{fun = "all"}, the plots of the three first indicators are produced.
#'
#' @param conf.int an argument expected to be TRUE if the confidence intervals of the
#' related-indicator specified by the argument "fun" are needed. The default
#' option is FALSE.
#'
#' @param conf.type One of "plain", "log" (the default), "log-log".
#' Only enough of the string to uniquely identify it is necessary.
#' The first option causes confidence intervals not to be generated.
#' The second causes the standard intervals curve +- k *se(curve),
#' where k is determined from conf.int. The log option calculates intervals
#'  based on the cumulative hazard or log(survival). The log-log option bases
#'  the intervals on the log(-log(curve)).
#'
#'
#' @param xlab label for the x-axis of the plot.
#'
#' @param ylab optional label for the y-axis of the plot. Depending to the curve
#' of interest (hazard, survival, probability of being cured at a given time t,
#'  or all),the argument must be named \code{ylab.haz, ylab.surv, ylab.ptcure}.
#'  If missing some default labels are provided depending on the curve of
#'  interest. This name can be found in the data.frame from the result of
#'  the \code{predict.curesurv} function.
#'
#'
#' @param ylab.haz optional label for the y-axis of the plot of excess hazard
#'
#'
#' @param ylab.surv optional label for the y-axis of the plot of net survival
#'
#' @param ylab.ptcure optional label for the y-axis of the plot of the probability
#'  \code{Pi(t)} of being cured at a given time t after diagnosis knowing that
#'   he/she was alive up to time t.
#'
#' @param col.haz optional argument to specify the color of curve of the excess hazard
#'
#'
#' @param col.surv optional argument to specify the color of curve of the net survival
#'
#' @param col.ptcure optional argument to specify the color of curve of probability
#'  \code{Pi(t)} of being cured at a given time t after diagnosis knowing that
#'   he/she was alive up to time \code{t}.
#'
#'
#' @param col.tau optional argument to specify the color of curve of time-to-null excess hazard
#'
#' @param col.ttc optional argument to specify the color of curve of time-to-cure
#'
#'
#' @param col.pi95 optional argument to specify the color of cure proportion with
#'  time-to-cure as indicator and \code{pi(t)>0.95}
#'
#' @param col.pi optional argument to specify the color of cure proportion
#'
#' @param lty.surv stands for line types for net survival
#'
#' @param lty.haz stands for line types for excess hazard
#'
#' @param lty.ptcure stands for line types for probability Pi(t) of being cured
#' at a given time t after diagnosis knowing that he/she was alive up to time t.
#'
#' @param lty.pi stands for line types for cure proportion
#'
#'
#' @param lty.tau stands for line types for time-to-null excess hazard
#'
#' @param lty.ttc stands for line types for time-to-cure
#'
#'
#' @param lty.pi95 stands for line types for \code{pi(t)>0.95}
#'
#'
#' @param ... additional options as in the classical plot method.
#'
#' @keywords plot.curesurv
#'
#' @return No value is returned.
#'
#'
#' @author Juste Goungounga, Eugenie Blandin, Olayidé Boussari, Valérie Jooste
#'
#' @examples
#'
#' \donttest{
#'
#' library("curesurv")
#' library("survival")
#'
#'  testiscancer$age_crmin <- (testiscancer$age- min(testiscancer$age)) /
#'               sd(testiscancer$age)
#'
#' fit_m1_ad_tneh <- curesurv(Surv(time_obs, event) ~ z_tau(age_crmin) +
#'                           z_alpha(age_crmin),
#'                           pophaz = "ehazard",
#'                           cumpophaz = "cumehazard",
#'                           model = "nmixture", dist = "tneh",
#'                           link_tau = "linear",
#'                           data = testiscancer,
#'                           method_opt = "L-BFGS-B")
#'
#'  fit_m1_ad_tneh
#'
#'
#' #'  #mean of age
#'  newdata1 <- with(testiscancer,
#'  expand.grid(event = 0, age_crmin = mean(age_crmin), time_obs  = seq(0.001,10,0.1)))
#'
#'  pred_agemean <- predict(object = fit_m1_ad_tneh, newdata = newdata1)
#'
#'
#'  #max of age
#'  newdata2 <- with(testiscancer,
#'  expand.grid(event = 0,
#'  age_crmin = max(age_crmin),
#'   time_obs  = seq(0.001,10,0.1)))
#'
#'  pred_agemax <- predict(object = fit_m1_ad_tneh, newdata = newdata2)
#'
#'    # predictions at time 2 years and  of age
#'
#'    newdata3 <- with(testiscancer,
#'       expand.grid(event = 0,
#'       age_crmin = seq(min(testiscancer$age_crmin),max(testiscancer$age_crmin), 0.1),
#'       time_obs  = 2))
#'
#'    pred_age_val <- predict(object = fit_m1_ad_tneh, newdata = newdata3)
#'
#'   #plot of net survival for mean and maximum age
#'
#'
#'
#'
#' par(mfrow = c(2, 2),
#'     cex = 1.0)
#' plot(pred_agemax$time,
#'     pred_agemax$ex_haz,
#'     type = "l",
#'     lty = 1,
#'     lwd = 2,
#'     xlab = "Time since diagnosis",
#'     ylab = "excess hazard")
#' lines(pred_agemean$time,
#'      pred_agemean$ex_haz,
#'      type = "l",
#'      lty = 2,
#'      lwd = 2)
#'
#' legend("topright",
#'       horiz = FALSE,
#'       legend = c("hE(t) age.max = 79.9", "hE(t) age.mean = 50.8"),
#'       col = c("black", "black"),
#'       lty = c(1, 2, 1, 1, 2, 2))
#' grid()
#'
#' plot(pred_agemax$time,
#'     pred_agemax$netsurv,
#'     type = "l",
#'     lty = 1,
#'     lwd = 2,
#'     ylim = c(0, 1),
#'     xlab = "Time since diagnosis",
#'     ylab = "net survival")
#' lines(pred_agemean$time,
#'      pred_agemean$netsurv,
#'      type = "l",
#'      lty = 2,
#'      lwd = 2)
#' legend("bottomleft",
#'        horiz = FALSE,
#'        legend = c("Sn(t) age.max = 79.9", "Sn(t) age.mean = 50.8"),
#'        col = c("black", "black"),
#'       lty = c(1, 2, 1, 1, 2, 2))
#' grid()
#'
#' plot(pred_agemax$time,
#'     pred_agemax$pt_cure,
#'     type = "l",
#'     lty = 1,
#'     lwd = 2,
#'     ylim = c(0, 1), xlim = c(0,30),
#'     xlab = "Time since diagnosis",
#'     ylab = "probability of being cured P(t)")
#'
#' lines(pred_agemean$time,
#'      pred_agemean$pt_cure,
#'      type = "l",
#'      lty = 2,
#'      lwd = 2)
#'
#'
#' abline(v = pred_agemean$tau[1],
#'       lty = 2,
#'       lwd = 2,
#'       col = "blue")
#' abline(v = pred_agemean$TTC[1],
#'        lty = 2,
#'        lwd = 2,
#'        col = "red")
#' abline(v = pred_agemax$tau[1],
#'        lty = 1,
#'        lwd = 2,
#'        col = "blue")
#' abline(v = pred_agemax$TTC[1],
#'        lty = 1,
#'        lwd = 2,
#'       col = "red")
#' grid()
#'
#' legend("bottomright",
#'        horiz = FALSE,
#'        legend = c("P(t) age.max = 79.9",
#'                  "P(t) age.mean = 50.8",
#'                  "TNEH age.max = 79.9",
#'                  "TTC age.max = 79.9",
#'                  "TNEH age.mean = 50.8",
#'                  "TTC age.mean = 50.8"),
#'       col = c("black", "black", "blue", "red", "blue", "red"),
#'       lty = c(1, 2, 1, 1, 2, 2))
#'
#'
#'  val_age <- seq(min(testiscancer$age_crmin),
#'                 max(testiscancer$age_crmin), 0.1) * sd(testiscancer$age) +
#'                 min(testiscancer$age)
#'
#'
#'  pred_age_val <- predict(object = fit_m1_ad_tneh, newdata = newdata3)
#'
#'
#' par(mfrow=c(2,2))
#'  plot(val_age,
#'      pred_age_val$ex_haz, type = "l",
#'      lty=1, lwd=2,
#'      xlab = "age",
#'      ylab = "excess hazard")
#' grid()
#'
#'  plot(val_age,
#'      pred_age_val$netsurv, type = "l", lty=1,
#'      lwd=2, xlab = "age", ylab = "net survival")
#'      grid()
#'
#'  plot(val_age,
#'      pred_age_val$pt_cure, type = "l", lty=1, lwd=2,
#'      xlab = "age",
#'      ylab = "Pi(t)")
#'      grid()
#' par(mfrow=c(1,1))
#'  }
#'
#'
#' @seealso [curesurv::predict.curesurv()], [curesurv::print.curesurv()], [curesurv::curesurv()], `browseVignettes("curesurv")`
#'
#' @import graphics
#' @export


plot.predCuresurv <- function(x,
                          fun = "all",
                          conf.int = FALSE,
                          conf.type = c("log", "log-log", "plain"),
                          xlab = "Time since diagnosis",
                          ylab.haz = "excess hazard",
                          ylab.surv = "net survival",
                          ylab.ptcure = "P(t)",
                          col.haz = "black",
                          col.surv = "black",
                          col.ptcure = "black",
                          col.tau = "red",
                          col.ttc = "black",
                          col.pi95 = "black",
                          col.pi = "blue",
                          lty.surv = 1, lty.haz = 1, lty.ptcure = 1,
                          lty.pi = 2,
                          lty.tau = 2, lty.ttc = 3, lty.pi95 = 4,
                          ...) {
  if (!inherits(x, "predCuresurv"))
    stop("Primary argument much be a predCuresurv object")

  my_args <- list(...)



  if ((fun == "all") | is.null(fun)) {

    if (conf.int == FALSE) {
      oldpar <- par()
      par(mfrow = c(2, 2))

      plot(x$time, x$ex_haz, type = "l",
           xlab = xlab,
           ylab = ylab.haz,
           col = col.haz,
           lty = lty.haz,...)
      abline(v = x$time_to_cure_ttc[1], col = col.ttc, lty = lty.ttc)

      if (x$dist[1] == "tneh") {
        abline(v = x$tau[1], col = col.tau, lty = lty.tau)
        legend("topright", legend = c("hazard", "TNEH",
                                      paste0("TTC: pi(t)>", (1 - x$epsilon[1]))),
               col = c(col.haz, col.tau, col.ttc),
               lty = c(lty.haz, lty.tau, lty.ttc))
      } else if (x$model[1] != "tneh") {
        legend("topright", legend = c(  paste0("TTC: pi(t)>", (1 - x$epsilon[1]))),
               col = c(col.ttc),
               lty = c(2, 2))
      }

      plot(x$time, x$netsurv, type = "l",
           xlab = xlab,
           ylab = ylab.surv,
           col = col.surv,
           ylim = c(0,1),
           lty = lty.surv,
           ...)
      abline(v = x$tau[1], col = col.tau, lty = lty.tau)
      abline(v = x$time_to_cure_ttc[1], col = col.ttc, lty = lty.ttc)

      if (x$dist[1] == "tneh") {
        abline(h = x$netsurv_tau[1], col = col.pi, lty = lty.pi)
        abline(v = x$tau[1], col = col.tau, lty = lty.tau)
        legend("bottomleft", legend = c("net survival",
                                      "TNEH",
                                      paste0("TTC: pi(t)>", (1 - x$epsilon[1])),
                                      "cure proportion"),
               col = c(col.surv, col.tau, col.ttc, col.pi),
               lty = c(lty.surv, lty.tau, lty.ttc, lty.pi))
      } else if (x$model[1] != "tneh") {
        legend("bottomleft", legend = c("net survival",
                                      paste0("TTC: pi(t)>", (1 - x$epsilon[1])),
                                      "cure proportion"),
               col = c(col.surv, col.ttc, col.pi),
               lty = c(lty.surv, lty.ttc, lty.pi))
      }



      plot(x$time,
           x$pt_cure, type = "l",
           xlab = xlab,
           ylab = ylab.ptcure,
           ylim = c(0, max(x$pt_cure)),
           xlim = c(0, max(x$time)),
           col = col.ptcure,
           lty = lty.ptcure,
           ...)
      abline(h = c(1 - x$epsilon[1]), col = col.pi95, lty = lty.pi95)
      abline(v = x$time_to_cure_ttc[1], col = col.ttc, lty = lty.ttc)

      if (x$dist[1] == "tneh") {
        abline(v = x$tau[1], col = col.tau, lty = lty.tau)

        legend("bottomright",
               legend = c("pi(t)", "tau", "ttc", paste0("pi(t)>", (1 - x$epsilon[1]))),
               col = c(col.ptcure, col.tau, col.ttc, col.pi95),
               lty = c(lty.ptcure, lty.tau, lty.ttc, lty.pi95))
      }else {
        legend("bottomright",
               legend = c("pi(t)", "ttc", paste0("pi(t)>", (1 - x$epsilon[1]))),
               col = c(col.ptcure, col.ttc, col.pi95),
               lty = c(lty.ptcure, lty.ttc, lty.pi95))

      }



      par(mfrow = c(1, 1))

    }
    else {
stop("not yet implemented")
    }


  } else if (fun == "haz") {

    if (conf.int == FALSE) {

      plot(x$time,
           x$ex_haz, type = "l",
           xlab = xlab, ylab = ylab.haz,
           col = col.haz, lty = lty.haz, ...)
      abline(v = x$time_to_cure_ttc[1], col = col.ttc, lty = 2)

      if (x$dist[1] == "tneh") {
        abline(v = x$tau[1], col = col.tau, lty = lty.tau)
        legend("topright", legend = c("hazard", "TNEH",
                                      paste0("TTC: pi(t)>", (1 - x$epsilon[1]))),
               col = c(col.haz, col.tau, col.ttc),
               lty = c(lty.haz, lty.tau,
                       lty.ttc))
      } else if (x$model[1] != "tneh") {
        legend("topright", legend = c(  paste0("TTC: pi(t)>", (1 - x$epsilon[1]))),
               col = c(col.ttc),
               lty = c(2, 2))
      }


    } else {
      stop("not yet implemented")
    }

  } else if (fun == "surv") {
    if (conf.int == FALSE) {

      plot(x$time, x$netsurv, type = "l",
           xlab = xlab,
           ylab = ylab.surv,
           col = col.surv,
           ylim = c(0,1), lty = lty.surv, ...)
      abline(v = x$tau[1], col = col.tau, lty = lty.tau)
      abline(v = x$time_to_cure_ttc[1], col = col.ttc, lty = lty.ttc)

      if (x$dist[1] == "tneh") {
        abline(h = x$netsurv_tau[1], col = col.pi, lty = lty.pi)
        abline(v = x$tau[1], col = col.tau, lty = lty.tau)
        legend("bottomleft", legend = c("net survival",
                                      "TNEH",
                                      paste0("TTC: pi(t)>", (1 - x$epsilon[1])),
                                      "cure proportion"),
               col = c(col.surv, col.tau, col.ttc, col.pi),
               lty = c(lty.surv, lty.tau, lty.ttc, lty.pi))
      } else if (x$model[1] != "tneh") {
        legend("bottomleft", legend = c("net survival",
                                      paste0("TTC: pi(t)>", (1 - x$epsilon[1])),
                                      "cure proportion"),
               col = c(col.surv, col.ttc, col.pi),
               lty = c(lty.surv, lty.ttc, lty.pi))
      }


    }
    else {
      stop("not yet implemented")
    }
  } else if (fun == "pt_cure") {

    if (conf.int == FALSE) {
      plot(x$time,
           x$pt_cure, type = "l",
           xlab = xlab,
           ylab = ylab.ptcure,
           ylim = c(0, max(x$pt_cure)),
           xlim = c(0, max(x$time)),
           col = col.ptcure,
           lty = lty.ptcure, ...)
      abline(h = c(1 - x$epsilon[1]), col = col.pi95, lty = lty.pi95)
      abline(v = x$time_to_cure_ttc[1], col = col.ttc, lty = lty.ttc)

      if (x$dist[1] == "tneh") {
        abline(v = x$tau[1], col = col.tau, lty = lty.tau)

        legend("bottomright",
               legend = c("pi(t)", "tau", "ttc", paste0("pi(t)>", (1 - x$epsilon[1]))),
               col = c(col.ptcure, col.tau, col.ttc, col.pi95),
               lty = c(lty.ptcure,lty.tau, lty.ttc, lty.pi95))
      }else {

        legend("bottomright",
               legend = c("pi(t)", "ttc", paste0("pi(t)>", (1 - x$epsilon[1]))),
               col = c(col.ptcure, col.ttc, col.pi95),
               lty = c(lty.ptcure, lty.ttc, lty.pi95))
      }



    } else {
      stop("not yet implemented")
    }

  } else if (fun == "cumhaz") {

    if (conf.int == FALSE) {
      par(mfrow = c(1, 1))


      plot(x$time, -log(x$netsurv), type = "l",
           xlab = xlab,
           ylab = ylab.surv,
           col = col.surv, ...)

      par(mfrow = c(1, 1))

    }
    else {
      stop("not yet implemented")
    }

  } else if (fun == "logcumhaz") {

    if (conf.int == FALSE) {
      plot(x$time, log(-log(x$netsurv)), type = "l",
           xlab = xlab,
           ylab = ylab.surv,
           col = col.surv,...)
    }
    else {
      stop("not yet implemented")
    }
  }
  oldpar
  invisible()

}

