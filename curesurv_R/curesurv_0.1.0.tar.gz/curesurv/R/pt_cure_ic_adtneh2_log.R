#' @title pt_cure_ic_adtneh2_log function
#'
#' @description calculates the probability of the probability Pi(t) of being
#' cured at a given time t after diagnosis knowing that he/she was alive up to
#' time t. It also provides the related confidence intervals using log method.
#'
#'
#' @param object ouput from a model implemented in curesurv
#'
#' @param z_alpha Covariates matrix acting on parameter alpha of the density of
#'  time-to-null excess hazard model
#'
#' @param z_tau Covariates matrix acting on time-to-null parameter.
#'
#' @param x time at which the predictions are provided
#'
#' @param level (1-alpha/2)-order quantile of a normal distribution


pt_cure_ic_adtneh2_log = function(z_tau = z_tau,
                                  z_alpha = z_alpha,
                                  x = x,
                                  object,
                                  level = level) {

  if (!inherits(object, "curesurv"))
    stop("Primary argument much be a curesurv object")


  D <- dpdtheta_adtneh2(z_alpha = z_alpha,
                        z_tau = z_tau,
                        x = x,
                        object = object)

  pt_cure <- cumLexc_ad2_topred(z_tau,
                                z_alpha,
                                x,
                                theta = object$coefficients)$pt_cure


  Dlog <- sweep(D, 1/pt_cure, MARGIN = 1, '*' )

  varlogpt <- diag(Dlog %*% object$varcov_star %*% t(Dlog))


  borne_inf <-  exp(log(pt_cure) - stats::qnorm(level) * sqrt(varlogpt))
  borne_sup <-  exp(log(pt_cure) + stats::qnorm(level) * sqrt(varlogpt))

  IC <- list(pt_cure = pt_cure,
             borne_inf = borne_inf,
             borne_sup = borne_sup)

  return(IC)

}
