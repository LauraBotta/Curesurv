#' @title varlog_sn_wei function
#'
#' @description Calculates the variance of logarithm of net survival with delta method on the log of net survival scale.
#'  Note that the expression calculated is Var(log(Sn(t))) = (dlog(Sn)/dtheta)Var(theta)(dlog(Sn)/dtheta)^T
#' where Var(theta) is the variance-covariance matrix of theta
#'
#' @param object ouput from a model implemented in curesurv
#'
#' @param z_ucured covariates matrix acting on survival function of uncured
#'
#' @param z_pcured covariates matrix acting on cure proportion
#'
#' @param x time at which the estimates are predicted
#'

varlog_sn_wei <- function(object, z_ucured =  z_ucured,
                          z_pcured = z_pcured,
                          x = x)
{
  dlogsndtheta_wei_n <- dlogsndtheta_wei(z_ucured =  z_ucured,
                                         z_pcured = z_pcured,
                                         x = x,
                                         theta = object$coefficients)

  if(object$pophaz.alpha) {
    varlog_sn_wei_n <- (dlogsndtheta_wei_n) %*%
      object$varcov_star[1:(ncol(object$varcov_star)-1),1:(ncol(object$varcov_star)-1)] %*%
      t(dlogsndtheta_wei_n)
  }else{
    varlog_sn_wei_n <- (dlogsndtheta_wei_n) %*%
      object$varcov_star %*%
      t(dlogsndtheta_wei_n)
  }



  return(varlog_sn_wei_n)
}
