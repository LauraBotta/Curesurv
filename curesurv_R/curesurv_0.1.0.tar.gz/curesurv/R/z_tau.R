#' @title z_tau function
#'
#' @description indicator variable.
#'
#' @param x a simple formula.
#'
#' @keywords z_tau
#'
#' @author Juste Goungounga, Eugenie Blandin, Olayidé Boussari, Valérie Jooste
#'
#' @references Boussari O, Bordes L, Romain G, Colonna M, Bossard N,
#'             Remontet L, Jooste V. Modeling excess hazard with time-to-cure
#'             as a parameter. Biometrics. 2020 Aug 31.
#'             doi: 10.1111/biom.13361. Epub ahead of print.
#'             PMID: 32869288.
#' (\href{https://pubmed.ncbi.nlm.nih.gov/32869288/}{pubmed})
#' @export
z_tau <- function(x){
  m.eval <- (quote(x))
  return(eval(m.eval))
}

