#' @title varlogp_wei function
#'
#' @description Variance of log(p(t)) with delta method. Var(log(p(t))) = (dlog(p(t)/dtheta)Var(theta)(dlog(p(t)/dtheta)^T
#' where Var(theta) is the variance-covariance matrix of theta
#'
#' @param object ouput from model implemented in curesurv
#'
#' @param z_ucured covariates matrix acting on survival function of uncured
#'
#' @param z_pcured covariates matrix acting on cure proportion
#'
#' @param x time at which the estimates are predicted

varlogp_wei <- function(object, z_pcured = z_pcured,
                        z_ucured = z_ucured, x)
{

  dlogpdtheta_n <- dlogpdtheta_wei(z_pcured = z_pcured,
                                                   z_ucured = z_ucured, x = x,
                                                   theta = object$coefficients)
if (object$pophaz.alpha) {
  var_logpt <- unlist(dlogpdtheta_n) %*%
    object$varcov_star[1:(ncol(object$varcov_star)-1), 1:(ncol(object$varcov_star)-1)] %*%
    do.call("rbind", dlogpdtheta_n)
}else{
  var_logpt <- unlist(dlogpdtheta_n) %*%
    object$varcov_star %*%
    do.call("rbind", dlogpdtheta_n)
}


  return(var_logpt)
}
