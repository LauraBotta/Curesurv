#' @title pi_ic_adtneh2 function
#'
#' @description produces confidence interval of cure fraction pi using a
#'  time-to-null excess hazard model with linear effect on parameter tau
#'  The confidence intervals calculation is based on the plain method.
#'
#'
#' @param z_tau Covariates matrix acting on time-to-null parameter.
#'
#'
#' @param z_alpha Covariates matrix acting on parameter alpha of the density of
#'  time-to-null excess hazard model
#'
#'
#' @param x time at which the predictions are provided
#'
#'
#' @param object ouput from a model implemented in curesurv
#'
#'
#' @param level \code{(1-alpha/2)}-order quantile of a normal distribution



pi_ic_adtneh2 <-  function(z_tau = z_tau,
                           z_alpha = z_alpha,
                           x = x,
                           object,
                           level = level) {

  pi <- cumLexc_ad2_topred(z_tau = z_tau,
                           z_alpha = z_alpha,
                           x = x,
                           theta = object$coefficients)$pi

  varpi <- diag(varpi_adtneh2(z_tau = z_tau,
                              z_alpha = z_alpha,
                              x = x,
                              object))

  borne_inf <-  pi -  stats::qnorm(level)  * sqrt(varpi)

  borne_sup <-  pi +  stats::qnorm(level)  * sqrt(varpi)

  IC <- list(pi = pi,
             borne_inf = borne_inf,
             borne_sup = borne_sup)

  return(IC)

}
